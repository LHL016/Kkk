#!/bin/sh
# One-command APK build. Usage: sh build-apk.sh [debug|release]
# Output: app/build/outputs/apk/<type>/
cd "$(dirname "$0")"
T="${1:-release}"
if [ "$T" = "debug" ]; then sh ./gradlew :app:assembleDebug; else sh ./gradlew :app:assembleRelease; fi
