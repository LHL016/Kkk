package com.soundwave.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.view.Choreographer
import android.view.Display
import java.io.File
import java.util.concurrent.Executors

/** Short rolling history for the sparklines. */
class Ring(private val cap: Int) {
    private val q = ArrayDeque<Double>()
    @Synchronized fun add(v: Double) { q.addLast(v); while (q.size > cap) q.removeFirst() }
    @Synchronized fun list(): List<Double> = q.toList()
}

/**
 * Device health while you play: system RAM, CPU, battery / thermal state, and this app's own cost.
 *
 * What Android lets a normal app read (no root, no ADB):
 *  - RAM: system-wide figures from ActivityManager. Exact.
 *  - CPU: /proc/stat is blocked for apps since Android 8, so the load is estimated from the current vs. maximum
 *    clock speed of each core when those files are readable. It is flagged as an estimate ("~"). The app's own CPU
 *    use (relay + monitoring threads) is always exact.
 *  - Temperature: battery temperature and the system thermal status (Android 10+).
 */
object SysStats {
    @Volatile var cpuPct = -1                 // -1 = not available on this device
    @Volatile var cpuEstimated = false
    @Volatile var appCpuPct = 0.0             // % of total CPU capacity used by SoundWave itself
    @Volatile var appRamMb = 0L
    @Volatile var ramPct = 0
    @Volatile var ramUsedMb = 0L
    @Volatile var ramTotalMb = 0L
    @Volatile var ramLow = false
    @Volatile var battPct = -1
    @Volatile var battTempC = -1f
    @Volatile var charging = false
    @Volatile var thermal = -1                // PowerManager thermal status 0..6, -1 = unknown
    @Volatile var cores = Runtime.getRuntime().availableProcessors()

    val cpuHist = Ring(60)
    val ramHist = Ring(60)
    val fpsHist = Ring(60)
    val tempHist = Ring(60)

    private var lastUpdate = 0L
    private var ticks = 0
    private var prevIdle = -1L
    private var prevTotal = -1L
    private var procStatOk = true
    private var freqOk = true
    private var prevCpuMs = -1L
    private var prevWall = -1L

    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "sw-stats").apply { isDaemon = true } }

    /** Samples on a background thread; cheap to call every second from the UI. */
    fun request(ctx: Context) {
        val app = ctx.applicationContext
        exec.execute { try { update(app) } catch (e: Exception) {} }
    }

    @Synchronized private fun update(ctx: Context) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastUpdate < 800) return
        lastUpdate = now

        // ---- RAM (system) ----
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        if (mi.totalMem > 0) {
            ramTotalMb = mi.totalMem / 1048576L
            ramUsedMb = (mi.totalMem - mi.availMem) / 1048576L
            ramPct = (100L * (mi.totalMem - mi.availMem) / mi.totalMem).toInt().coerceIn(0, 100)
            ramLow = mi.lowMemory
            ramHist.add(ramPct.toDouble())
        }
        if (ticks % 5 == 0) appRamMb = Debug.getPss() / 1024L          // own process, KB -> MB

        // ---- CPU (system) ----
        val st = readProcStat()
        if (st != null) {
            if (prevTotal >= 0 && st[1] > prevTotal) {
                val dTotal = st[1] - prevTotal; val dIdle = st[0] - prevIdle
                cpuPct = (100L * (dTotal - dIdle) / dTotal).toInt().coerceIn(0, 100); cpuEstimated = false
            }
            prevIdle = st[0]; prevTotal = st[1]
        } else {
            val f = freqLoad()
            cpuPct = f; cpuEstimated = f >= 0
        }
        if (cpuPct >= 0) cpuHist.add(cpuPct.toDouble())

        // ---- CPU (this app) ----
        val cpuMs = Process.getElapsedCpuTime()
        if (prevCpuMs >= 0 && now > prevWall) {
            appCpuPct = (100.0 * (cpuMs - prevCpuMs) / ((now - prevWall).toDouble() * cores)).coerceIn(0.0, 100.0)
        }
        prevCpuMs = cpuMs; prevWall = now

        // ---- battery / thermal ----
        val b: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            battPct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1
            val t = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            battTempC = if (t == Int.MIN_VALUE) -1f else t / 10f
            val status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            if (battTempC > 0) tempHist.add(battTempC.toDouble())
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try { thermal = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus } catch (e: Exception) {}
        }
        if (FpsMeter.fps > 0) fpsHist.add(FpsMeter.fps.toDouble())
        ticks++
    }

    private fun readProcStat(): LongArray? {
        if (!procStatOk) return null
        return try {
            val line = File("/proc/stat").bufferedReader().use { it.readLine() }
            val p = line.trim().split(Regex("\\s+"))
            if (p.size < 8 || p[0] != "cpu") { procStatOk = false; null }
            else {
                val v = LongArray(8) { p[it + 1].toLong() }
                longArrayOf(v[3] + v[4], v.sum())                      // idle + iowait, total
            }
        } catch (e: Exception) { procStatOk = false; null }
    }

    private fun readLong(path: String): Long = try { File(path).readText().trim().toLong() } catch (e: Exception) { -1L }

    /** Average of (current clock / max clock) over the cores that expose it. -1 when the device hides cpufreq. */
    private fun freqLoad(): Int {
        if (!freqOk) return -1
        var sum = 0.0; var n = 0
        for (i in 0 until cores) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val cur = readLong(base + "scaling_cur_freq")
            var max = readLong(base + "cpuinfo_max_freq"); if (max <= 0) max = readLong(base + "scaling_max_freq")
            if (cur > 0 && max > 0) { sum += cur.toDouble() / max; n++ }
        }
        if (n == 0) { freqOk = false; return -1 }
        return Math.round(100.0 * sum / n).toInt().coerceIn(0, 100)
    }

    fun thermalName(): String = when (thermal) {
        0 -> "Normal"; 1 -> "Light throttling"; 2 -> "Moderate throttling"; 3 -> "Severe throttling"
        4 -> "Critical"; 5 -> "Emergency"; 6 -> "Shutdown risk"; else -> "Unknown"
    }
    /** 0 fine, 1 warm, 2 hot, 3 unknown. */
    fun heatLevel(): Int = when {
        thermal >= 3 || battTempC >= 43f -> 2
        thermal >= 1 || battTempC >= 38f -> 1
        thermal < 0 && battTempC < 0 -> 3
        else -> 0
    }
}

/**
 * Display frame meter. A normal app cannot read another app's frame rate (that needs ADB/system access), so this
 * measures what the screen is really delivering while the overlay is visible: frames per second and how many frames
 * arrived late ("jank"). When the game is running at its cap, this tracks the refresh rate the system picked for it;
 * drops mean the device is struggling (thermal throttling, heavy load).
 */
object FpsMeter : Choreographer.FrameCallback {
    @Volatile var fps = 0
    @Volatile var jankPct = 0
    @Volatile var refreshHz = 60f
    private var running = false
    private var winStart = 0L
    private var lastT = 0L
    private var frames = 0
    private var janks = 0

    fun displayHz(ctx: Context): Float = try {
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        if (d != null && d.refreshRate > 20f) d.refreshRate else 60f
    } catch (e: Exception) { 60f }

    private val owners = HashSet<String>()

    /** Must be called on the main thread. The meter runs while at least one owner ("overlay", "app") wants it. */
    fun start(owner: String, hz: Float) {
        refreshHz = if (hz > 20f) hz else 60f
        owners.add(owner)
        if (running) return
        running = true; winStart = 0L; lastT = 0L; frames = 0; janks = 0
        Choreographer.getInstance().postFrameCallback(this)
    }

    /** Must be called on the main thread. */
    fun stop(owner: String) {
        owners.remove(owner)
        if (owners.isNotEmpty() || !running) return
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
        fps = 0; jankPct = 0
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        if (lastT != 0L && (frameTimeNanos - lastT).toDouble() > 1.5e9 / refreshHz) janks++
        lastT = frameTimeNanos
        if (winStart == 0L) winStart = frameTimeNanos
        else {
            frames++
            val span = frameTimeNanos - winStart
            if (span >= 1_000_000_000L) {
                fps = Math.round(frames * 1e9 / span).toInt()
                jankPct = if (frames > 0) Math.round(100f * janks / frames) else 0
                winStart = frameTimeNanos; frames = 0; janks = 0
            }
        }
        Choreographer.getInstance().postFrameCallback(this)
    }
}
