package com.soundwave.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

const val APP_NAME = "SoundWave"

enum class CountryMode { OFF, ALLOW, BLOCK }

object Countries {
    val all: List<Pair<String, String>> = (
        "JP:Japan,KR:South Korea,CN:China,HK:Hong Kong,TW:Taiwan,SG:Singapore,MY:Malaysia,TH:Thailand,VN:Vietnam," +
        "ID:Indonesia,PH:Philippines,IN:India,BD:Bangladesh,PK:Pakistan,LK:Sri Lanka,NP:Nepal,AE:United Arab Emirates," +
        "SA:Saudi Arabia,QA:Qatar,KW:Kuwait,OM:Oman,TR:Turkey,IL:Israel,EG:Egypt,ZA:South Africa,NG:Nigeria,KE:Kenya," +
        "GB:United Kingdom,IE:Ireland,FR:France,DE:Germany,NL:Netherlands,BE:Belgium,ES:Spain,PT:Portugal,IT:Italy," +
        "CH:Switzerland,AT:Austria,SE:Sweden,NO:Norway,DK:Denmark,FI:Finland,PL:Poland,CZ:Czechia,RO:Romania," +
        "UA:Ukraine,RU:Russia,GR:Greece,US:United States,CA:Canada,MX:Mexico,BR:Brazil,AR:Argentina,CL:Chile," +
        "CO:Colombia,PE:Peru,AU:Australia,NZ:New Zealand"
    ).split(",").map { val p = it.split(":"); p[0] to p[1] }.sortedBy { it.second }

    val regions: Map<String, List<String>> = linkedMapOf(
        "Asia" to listOf("JP", "KR", "CN", "HK", "TW", "SG", "MY", "TH", "VN", "ID", "PH", "IN", "BD", "PK", "LK", "NP"),
        "Middle East" to listOf("AE", "SA", "QA", "KW", "OM", "TR", "IL"),
        "Europe" to listOf("GB", "IE", "FR", "DE", "NL", "BE", "ES", "PT", "IT", "CH", "AT", "SE", "NO", "DK", "FI", "PL", "CZ", "RO", "UA", "RU", "GR"),
        "Americas" to listOf("US", "CA", "MX", "BR", "AR", "CL", "CO", "PE"),
        "Oceania" to listOf("AU", "NZ"),
        "Africa" to listOf("EG", "ZA", "NG", "KE")
    )

    fun name(code: String) = all.firstOrNull { it.first == code }?.second ?: code
    fun flag(code: String) =
        if (code.length == 2) code.map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("") else "🌐"
}

/** A UDP packet held until the server's country is known. */
class Held(val sp: Int, val dp: Int, val dst: Int, val data: ByteArray)

/** One stay on a match server (20 s or longer). avg/min/max are -1 when the server never answered ping. */
class Session(val ip: String, val cc: String, val place: String, val start: Long, val end: Long,
              val avg: Double, val min: Double, val max: Double, val jitter: Double, val loss: Int)

class Server(val ip: String) {
    @Volatile var port = 0                                   // most recent port seen
    val ports: MutableSet<Int> = ConcurrentHashMap.newKeySet<Int>()
    @Volatile var country = "?"
    @Volatile var place = "looking up..."
    @Volatile var isp = ""
    @Volatile var geo = 0                                    // 0 = pending, 1 = known, 2 = failed
    @Volatile var lastSeen = 0L
    @Volatile var notified = false                           // a "blocked" alert was already raised for this server
    @Volatile var okCache = true                             // cached filter decision (see GameVpnService.decide)
    @Volatile var okAt = 0L
    @Volatile var geoStarted = false
    @Volatile var geoWaitDone = false                        // gave up waiting for the location (fail-open)
    @Volatile var heldCount = 0                              // packets held while the location is looked up
    @Volatile var heldSince = 0L
    val held = ArrayList<Held>()
    @Volatile var lastPing = 0L
    @Volatile var pinging = false
    @Volatile var hits = 0L                                  // packets sent to this IP
    @Volatile var autoBlocked = false
    @Volatile var autoReason = ""
    @Volatile var noReply = 0                                // probe bursts that got no answer from a server that never answered
    @Volatile var via = "ICMP"                               // how the last ping was measured: ICMP or TCP
    @Volatile var bad = 0                                    // consecutive readings over the limits
    @Volatile var good = 0                                   // consecutive readings within the limits
    var blockedManual: Boolean                               // persisted, per IP
        get() = ip in Monitor.blockSet
        set(v) { if (v) Monitor.blockSet.add(ip) else Monitor.blockSet.remove(ip); Monitor.save() }
    var trusted: Boolean                                     // persisted; filters never block a trusted server
        get() = ip in Monitor.trustSet
        set(v) { if (v) Monitor.trustSet.add(ip) else Monitor.trustSet.remove(ip); Monitor.save() }
    val blocked: Boolean get() = !Monitor.allowed(this)
    /** 0 = not known yet, 1 = Konami/game server (cloud or hosting network), 2 = peer (home / mobile ISP). */
    val kind: Int get() = Monitor.kindOf(this)
    /** A server in the Delhi / Mumbai area (closest to the user). */
    val near: Boolean get() = Monitor.isNear(this)

    // Passive ping for servers that ignore ICMP and TCP: gap between our first unanswered game packet and the next reply
    // (an upper bound that includes server tick time; the 2 s minimum keeps it close to the real round trip).
    @Volatile var sendNs = 0L
    @Volatile var passive = false
    private var pMin = Double.MAX_VALUE
    private var pAt = 0L
    fun notePassive() {
        val t = sendNs; if (t == 0L) return
        sendNs = 0L
        val d = (System.nanoTime() - t) / 1e6
        if (d < 400) synchronized(this) { if (d < pMin) pMin = d }
    }
    fun flushPassive(now: Long) {
        if (now - pAt < 2000) return
        pAt = now
        val v: Double
        synchronized(this) { v = pMin; pMin = Double.MAX_VALUE }
        if (v == Double.MAX_VALUE) return
        if (samples() == 0 && noReply >= 1 || passive) { passive = true; addRtt(v) }
    }
    @Synchronized fun clearRtts() { rtts.clear() }

    private val rtts = ArrayDeque<Double>()                 // ICMP round-trip samples, ms (decimals kept)
    private val probes = ArrayDeque<Boolean>()               // true = answered; used for packet loss
    private fun median(l: List<Double>): Double {
        if (l.isEmpty()) return 0.0
        val s = l.sorted(); val m = s.size / 2
        return if (s.size % 2 == 1) s[m] else (s[m - 1] + s[m]) / 2
    }
    @Synchronized fun addRtt(ms: Double) { rtts.addLast(ms); if (rtts.size > 40) rtts.removeFirst() }
    @Synchronized fun addProbe(ok: Boolean) { probes.addLast(ok); if (probes.size > 60) probes.removeFirst() }
    @Synchronized fun samples() = rtts.size
    @Synchronized fun probed() = probes.isNotEmpty() || noReply > 0
    /** Current ping: median of the last 7 samples, so single spikes don't move it. */
    @Synchronized fun cur(): Double = median(rtts.toList().takeLast(7))
    @Synchronized fun recentAvg(n: Int) = Math.round(median(rtts.toList().takeLast(maxOf(n, 5)))).toInt()
    @Synchronized fun avg() = if (rtts.isEmpty()) -1 else Math.round(rtts.average()).toInt()
    @Synchronized fun minRtt(): Double = rtts.minOrNull() ?: 0.0
    /** Jitter: mean absolute difference between consecutive samples (burst samples are 0.2 s apart). */
    @Synchronized fun jitterD(): Double {
        val l = rtts.toList().takeLast(20)
        return if (l.size < 2) 0.0 else l.zipWithNext { x, y -> Math.abs(y - x) }.average()
    }
    @Synchronized fun jitter() = Math.round(jitterD()).toInt()
    /** Loss is only meaningful for a server that has answered at least once; otherwise it is unknown (reported as 0). */
    @Synchronized fun lossPct(): Int = if (probes.isEmpty() || rtts.isEmpty()) 0 else Math.round(100f * probes.count { !it } / probes.size)
    @Synchronized fun probeCount() = probes.size
    @Synchronized fun series(): List<Double> = rtts.toList()
}

object Monitor {
    val servers = ConcurrentHashMap<String, Server>()
    val blockSet: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()
    val trustSet: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()
    private val geoCache = ConcurrentHashMap<String, Array<String>>()   // survives Stop/Start

    // ---- filter settings (persisted) ----
    @Volatile var countryMode = CountryMode.OFF
    @Volatile var countries: Set<String> = emptySet()
    @Volatile var autoOn = false
    @Volatile var maxPing = 100
    @Volatile var maxJitter = 0            // 0 = ignore jitter
    @Volatile var strikes = 3              // consecutive bad readings before blocking / good ones before unblocking
    @Volatile var autoUnblock = true
    // ---- alerts (turned into notifications / the overlay banner by the services) ----
    @Volatile var eventId = 0
    @Volatile var eventKind = 0            // 1 server blocked, 2 lag spike, 3 match ended
    @Volatile var eventText = ""
    @Volatile var bannerText = ""
    @Volatile var bannerKind = 0
    @Volatile var bannerUntil = 0L
    @Volatile var liveSince = 0L
    @Volatile var idleStopMin = 30         // stop monitoring after this many minutes without game traffic, 0 = never
    @Volatile var maxLoss = 0              // % packet loss limit, 0 = ignore
    @Volatile var filtersEnabled = true    // master switch: pauses country + auto filters (your own blocks still apply)
    @Volatile var haptics = true
    @Volatile var lastGame = ""
    // ---- overlay stats (persisted) ----
    @Volatile var ovFps = true
    @Volatile var ovCpu = true
    @Volatile var ovRam = true
    @Volatile var ovTemp = true
    @Volatile var blockV6 = true           // route IPv6 into the tunnel and drop it, so the game can't bypass filters over IPv6

    // ---- router health, live match server, session history ----
    val gw = Server("gateway")
    @Volatile var netType = "Network"
    @Volatile var gwIp = ""
    val history: MutableList<Session> = java.util.Collections.synchronizedList(ArrayList<Session>())
    @Volatile var live: Server? = null
    private val scores = HashMap<String, Double>()
    private val lastHits = HashMap<String, Long>()
    private val sessPings = ArrayList<Double>()
    private var sessServer: Server? = null
    private var sessStart = 0L

    @Volatile var running = false
    @Volatile var lastError = ""
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.getSharedPreferences("soundwave", Context.MODE_PRIVATE); prefs = p
        countryMode = try { CountryMode.valueOf(p.getString("cmode", "OFF")!!) } catch (e: Exception) { CountryMode.OFF }
        countries = list(p.getString("countries", "")).toSet()
        autoOn = p.getBoolean("autoOn", false); maxPing = p.getInt("maxPing", 100)
        maxJitter = p.getInt("maxJitter", 0); strikes = p.getInt("strikes", 3); autoUnblock = p.getBoolean("autoUnblock", true)
        blockSet.addAll(list(p.getString("blocks", ""))); trustSet.addAll(list(p.getString("trusts", "")))
        maxLoss = p.getInt("maxLoss", 0); haptics = p.getBoolean("haptics", true); lastGame = p.getString("lastGame", "") ?: ""
        filtersEnabled = p.getBoolean("filtersOn", true); idleStopMin = p.getInt("idleStop", 30)
        ovFps = p.getBoolean("ovFps", true); ovCpu = p.getBoolean("ovCpu", true); ovRam = p.getBoolean("ovRam", true)
        ovTemp = p.getBoolean("ovTemp", true); blockV6 = p.getBoolean("blockV6", true)
        try {
            val g = JSONObject(p.getString("geo", "{}"))
            for (k in g.keys()) { val a = g.getJSONArray(k); geoCache[k] = arrayOf(a.getString(0), a.getString(1), a.getString(2)) }
        } catch (e: Exception) {}
        try {
            val arr = JSONArray(p.getString("history", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                history.add(Session(o.getString("ip"), o.getString("cc"), o.getString("place"), o.getLong("start"), o.getLong("end"),
                    o.getDouble("avg"), o.getDouble("min"), o.getDouble("max"), o.getDouble("jitter"), o.getInt("loss")))
            }
        } catch (e: Exception) {}
    }

    private fun list(s: String?) = (s ?: "").split(",").filter { it.isNotBlank() }

    fun save() {
        prefs?.edit()?.putString("cmode", countryMode.name)?.putString("countries", countries.joinToString(","))
            ?.putBoolean("autoOn", autoOn)?.putInt("maxPing", maxPing)?.putInt("maxJitter", maxJitter)
            ?.putInt("strikes", strikes)?.putBoolean("autoUnblock", autoUnblock)
            ?.putString("blocks", blockSet.joinToString(","))?.putString("trusts", trustSet.joinToString(","))
            ?.putInt("maxLoss", maxLoss)?.putBoolean("haptics", haptics)?.putString("lastGame", lastGame)?.putBoolean("filtersOn", filtersEnabled)?.putInt("idleStop", idleStopMin)
            ?.putBoolean("ovFps", ovFps)?.putBoolean("ovCpu", ovCpu)?.putBoolean("ovRam", ovRam)?.putBoolean("ovTemp", ovTemp)
            ?.putBoolean("blockV6", blockV6)?.apply()
    }

    /** Known locations (cached on disk) are applied immediately, so repeat servers are filtered with no lookup delay. */
    fun server(ip: String): Server = servers.getOrPut(ip) {
        Server(ip).also { s ->
            geoCache[ip]?.let { s.country = it[0]; s.place = it[1]; s.isp = it[2]; s.geo = 1; s.geoStarted = true }
        }
    }

    // ---- peer vs server detection ----
    private val hostingRx = Regex("konami|amazon|aws|google|microsoft|azure|alibaba|tencent|oracle|akamai|cloudflare|ovh|digitalocean|" +
        "leaseweb|equinix|hosting|datacenter|data center|cloud|colo|vultr|linode|choopa|packet|softlayer|ibm|hetzner|cdn77|zenlayer|ucloud|gcore|tata comm|nxtra|ctrls", RegexOption.IGNORE_CASE)
    private val nearRx = Regex("delhi|mumbai|maharashtra|navi mumbai|thane|noida|gurgaon|gurugram", RegexOption.IGNORE_CASE)
    fun kindOf(s: Server): Int = when {
        s.geo != 1 || s.isp.isEmpty() -> 0
        hostingRx.containsMatchIn(s.isp) -> 1
        else -> 2
    }
    fun isNear(s: Server) = s.kind == 1 && nearRx.containsMatchIn(s.place)

    // ---- rules ----
    /** Unknown location (lookup pending/failed) is never filtered, so a slow lookup can't break a connection. */
    fun countryBlocked(s: Server): Boolean {
        if (countryMode == CountryMode.OFF || s.geo != 1) return false
        if (countryMode == CountryMode.ALLOW && countries.isEmpty()) return false   // nothing selected = no filter
        val inSet = s.country in countries
        return if (countryMode == CountryMode.ALLOW) !inSet else inSet
    }

    fun allowed(s: Server): Boolean = when {
        s.blockedManual -> false
        s.trusted -> true
        !filtersEnabled -> true
        autoOn && s.autoBlocked -> false
        else -> !countryBlocked(s)
    }

    fun needsGeoEarly() = filtersEnabled && countryMode != CountryMode.OFF && !(countryMode == CountryMode.ALLOW && countries.isEmpty())
    /** True while a country filter is waiting for this server's location (packets are held, not dropped). */
    fun needsGeo(s: Server) = needsGeoEarly() && s.geo == 0 && !s.geoWaitDone && !s.trusted && !s.blockedManual

    fun reason(s: Server): String? = when {
        s.blockedManual -> "Blocked by you"
        s.trusted -> null
        !filtersEnabled -> null
        autoOn && s.autoBlocked -> s.autoReason.ifEmpty { "Auto-blocked" }
        countryBlocked(s) -> "Country filter: ${Countries.name(s.country)}"
        else -> null
    }

    /** Tap action: a blocked server becomes trusted (filters skip it); anything else is blocked manually. */
    fun toggle(s: Server) {
        if (s.blocked) { s.autoBlocked = false; s.blockedManual = false; s.trusted = true }
        else { s.trusted = false; s.blockedManual = true }
    }

    private fun saveHistory() {
        val arr = JSONArray()
        synchronized(history) {
            history.forEach { s ->
                arr.put(JSONObject().put("ip", s.ip).put("cc", s.cc).put("place", s.place).put("start", s.start).put("end", s.end)
                    .put("avg", s.avg).put("min", s.min).put("max", s.max).put("jitter", s.jitter).put("loss", s.loss))
            }
        }
        prefs?.edit()?.putString("history", arr.toString())?.apply()
    }
    fun clearHistory() { history.clear(); saveHistory() }

    /** Router health: 0 fine, 1 unsteady, 2 bad, 3 unknown / not available. */
    fun netLevel(): Int = when {
        netType == "Mobile" || gw.samples() == 0 -> 3
        gw.cur() > 40 || gw.lossPct() >= 5 -> 2
        gw.cur() > 20 || gw.jitterD() > 10 || gw.lossPct() >= 2 -> 1
        else -> 0
    }
    fun netText(): String = when (netLevel()) {
        0 -> "Local network looks fine"
        1 -> "Your $netType is a bit unsteady"
        2 -> if (netType == "Wi-Fi") "Your Wi-Fi/router is adding lag" else "Your local network is adding lag"
        else -> if (netType == "Mobile") "Mobile data: router ping isn't available" else "Measuring your network..."
    }

    /** Call about once a second. Picks the live match server (most recent traffic, with hysteresis) and records sessions. */
    @Synchronized fun updateLive(now: Long) {
        // Forget servers that went quiet 10+ minutes ago (your block/trust lists are kept separately), so the map can't grow forever.
        val iter = servers.values.iterator()
        while (iter.hasNext()) {
            val old = iter.next()
            if (old !== live && old.lastSeen > 0 && now - old.lastSeen > 600000) { iter.remove(); scores.remove(old.ip); lastHits.remove(old.ip) }
        }
        for (s in servers.values) {
            val d = s.hits - (lastHits[s.ip] ?: s.hits); lastHits[s.ip] = s.hits
            scores[s.ip] = (scores[s.ip] ?: 0.0) * 0.5 + d
        }
        fun sc(s: Server) = scores[s.ip] ?: 0.0
        val cand = servers.values.filter { now - it.lastSeen < 5000 && !it.blocked && sc(it) > 0.0 }.maxByOrNull { sc(it) }
        val cur = live
        val curOk = cur != null && now - cur.lastSeen < 5000 && !cur.blocked && sc(cur) > 0.0
        val next = if (curOk && (cand == null || cand === cur || sc(cand) < 1.5 * sc(cur!!) + 2)) cur else cand
        val keep = next ?: cur?.takeIf { now - it.lastSeen < 10000 }
        if (keep !== cur) {
            endSession(now)
            liveSince = now
            if (keep != null) { sessServer = keep; sessStart = now }
        }
        live = keep
        if (keep != null && keep.samples() > 0) sessPings.add(keep.cur())
    }

    @Synchronized fun endSession(now: Long) {
        val s = sessServer
        if (s != null && now - sessStart >= 20000) {
            val sorted = sessPings.sorted()
            history.add(Session(s.ip, s.country, s.place, sessStart, now,
                if (sorted.isEmpty()) -1.0 else sorted.average(), sorted.firstOrNull() ?: -1.0, sorted.lastOrNull() ?: -1.0,
                s.jitterD(), s.lossPct()))
            while (history.size > 150) history.removeAt(0)
            saveHistory()
            pushEvent(3, "Match ended: ${Countries.flag(s.country)} ${s.place.ifEmpty { s.ip }} · " +
                (if (sorted.isEmpty()) "no ping data"
                 else "avg ${fmt(sorted.average())} ms · jitter ${fmt(s.jitterD())} · loss ${s.lossPct()}% · grade ${gradeOf(sorted.average(), s.jitterD(), s.lossPct())}"))
        }
        sessServer = null; sessPings.clear()
    }

    fun pushEvent(kind: Int, text: String) {
        eventKind = kind; eventText = text
        bannerText = text; bannerKind = kind; bannerUntil = System.currentTimeMillis() + 9000
        eventId++
    }

    /** Gaming grade from ping + 2 x jitter + 6 x loss%: A under 60, B under 100, C under 150, D worse. */
    fun gradeOf(ping: Double, jitter: Double, loss: Int): Char {
        if (ping < 0) return '?'
        val sc = ping + 2 * jitter + 6 * loss
        return when { sc < 60 -> 'A'; sc < 100 -> 'B'; sc < 150 -> 'C'; else -> 'D' }
    }
    fun grade(s: Server): Char = if (s.samples() == 0) '?' else gradeOf(s.cur(), s.jitterD(), s.lossPct())

    fun fmt(d: Double): String = if (d < 10) String.format(java.util.Locale.US, "%.1f", d) else Math.round(d).toString()

    /** Called with every ICMP burst: [rtts] = answered samples (ms), [sent] = probes sent. */
    fun onBurst(s: Server, rtts: List<Double>, sent: Int) {
        if (s.passive) {
            if (rtts.isEmpty()) return                           // keep the passive reading, don't count it as loss
            s.passive = false; s.clearRtts()                     // a real probe finally got through: it replaces the estimate
        }
        for (r in rtts) s.addRtt(r)
        if (rtts.isEmpty() && s.samples() == 0) {
            // Never answered (ICMP and TCP both silent): that is "can't measure", not "100% packet loss".
            s.noReply++
            return
        }
        s.noReply = 0
        for (i in 1..sent) s.addProbe(i <= rtts.size)
        if (rtts.isEmpty()) return
        val med = rtts.sorted()[rtts.size / 2]
        val overPing = med > maxPing
        val overJitter = maxJitter > 0 && s.samples() >= 6 && s.jitterD() > maxJitter
        val overLoss = maxLoss > 0 && s.probeCount() >= 12 && s.lossPct() > maxLoss
        if (overPing || overJitter || overLoss) { s.bad++; s.good = 0 } else { s.good++; s.bad = 0 }
        if (!autoOn || !filtersEnabled || s.trusted || s.blockedManual) return
        val need = if (overPing && med > maxPing * 1.5) 1 else strikes      // clearly bad servers are rejected on the first reading
        if (!s.autoBlocked && s.bad >= need) {
            s.autoReason = when {
                overPing -> "Ping ${fmt(med)} ms over your $maxPing ms limit"
                overJitter -> "Jitter ${fmt(s.jitterD())} ms over your $maxJitter ms limit"
                else -> "Packet loss ${s.lossPct()}% over your $maxLoss% limit"
            }
            s.autoBlocked = true
        } else if (s.autoBlocked && autoUnblock && s.good >= strikes) s.autoBlocked = false
    }

    private fun saveGeo() {
        if (geoCache.size > 400) geoCache.keys.take(200).forEach { geoCache.remove(it) }
        val o = JSONObject()
        for ((k, v) in geoCache) o.put(k, JSONArray().put(v[0]).put(v[1]).put(v[2]))
        prefs?.edit()?.putString("geo", o.toString())?.apply()
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 3000; c.readTimeout = 3000
            c.setRequestProperty("User-Agent", "$APP_NAME/2.0")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    /** Returns [country code, "City, Country", isp], or null when the provider answered but doesn't know the IP. */
    private fun geoPrimary(ip: String): Array<String>? {
        val j = JSONObject(httpGet("https://ipwho.is/$ip"))
        if (!j.optBoolean("success")) return null
        val place = listOf(j.optString("city"), j.optString("country")).filter { it.isNotEmpty() }.joinToString(", ")
        val isp = j.optJSONObject("connection")?.optString("isp") ?: ""
        return arrayOf(j.optString("country_code", "?"), place, isp)
    }

    private fun geoFallback(ip: String): Array<String>? {
        val j = JSONObject(httpGet("https://ipapi.co/$ip/json/"))
        if (j.optBoolean("error") || j.optString("country_code").isEmpty()) return null
        val place = listOf(j.optString("city"), j.optString("country_name")).filter { it.isNotEmpty() }.joinToString(", ")
        return arrayOf(j.optString("country_code"), place, j.optString("org"))
    }

    fun lookup(s: Server) {
        if (s.geoStarted) return
        s.geoStarted = true
        Thread {
            var answered = false                                  // true once a provider replied (even "unknown")
            attempts@ for (attempt in 1..4) {
                // alternate providers: a rate limit or outage on one must not leave the server without a location
                for (turn in 0..1) {
                    try {
                        val r = if ((attempt + turn) % 2 == 1) geoPrimary(s.ip) else geoFallback(s.ip)
                        answered = true
                        if (r != null) {
                            s.country = r[0].uppercase(); s.place = r[1]; s.isp = r[2]
                            geoCache[s.ip] = arrayOf(s.country, s.place, s.isp)
                            s.geo = 1
                            saveGeo()
                            return@Thread
                        }
                    } catch (e: Exception) {
                        s.place = "lookup failed (retrying)"
                    }
                }
                if (answered) break@attempts                      // both providers gave an answer without a location
                try { Thread.sleep(1500) } catch (x: Exception) {}
            }
            if (answered) { s.place = "unknown"; s.geo = 2 } else { s.place = "lookup failed"; s.geo = 2 }
        }.start()
    }
}
