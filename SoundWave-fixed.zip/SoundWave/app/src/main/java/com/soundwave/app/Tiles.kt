package com.soundwave.app

import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile: start/stop monitoring (needs the one-time VPN permission from the app). */
class MonitorTile : TileService() {
    override fun onStartListening() = refresh()

    override fun onClick() {
        Monitor.init(applicationContext)
        if (Monitor.running) {
            startService(Intent(this, GameVpnService::class.java).setAction(GameVpnService.ACTION_STOP))
            refresh(false)
        } else {
            val pkg = Monitor.lastGame
            if (pkg.isEmpty() || VpnService.prepare(this) != null) { openApp(); return }   // pick a game / grant VPN once
            startService(Intent(this, GameVpnService::class.java).putExtra(GameVpnService.EXTRA_PKG, pkg))
            refresh(true)
        }
    }

    private fun refresh(on: Boolean = Monitor.running) {
        val t = qsTile ?: return
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "SoundWave"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (on) "Monitoring" else "Off"
        t.updateTile()
    }

    @Suppress("DEPRECATION")
    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        else startActivityAndCollapse(i)
    }
}

/** Quick Settings tile: pause/resume all filters (country + auto) without stopping monitoring. */
class FilterTile : TileService() {
    override fun onStartListening() = refresh()

    override fun onClick() {
        Monitor.init(applicationContext)
        Monitor.filtersEnabled = !Monitor.filtersEnabled
        Monitor.save(); refresh()
    }

    private fun refresh() {
        Monitor.init(applicationContext)
        val t = qsTile ?: return
        t.state = if (Monitor.filtersEnabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Filters"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (Monitor.filtersEnabled) "On" else "Paused"
        t.updateTile()
    }
}
