package com.soundwave.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.view.View

/** Tiny line graph with a soft fill. Scale is 0..max (at least [minTop]) unless [fixedMax] is set (e.g. 100 for percentages). */
class Spark(ctx: Context) : View(ctx) {
    var data: List<Double> = emptyList()
    var color: Int = Color.GRAY
    var fixedMax: Double = 0.0
    var minTop: Double = 50.0
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onDraw(c: Canvas) {
        if (data.size < 2 || width == 0 || height == 0) return
        val top = if (fixedMax > 0) fixedMax else maxOf((data.maxOrNull() ?: 0.0) * 1.15, minTop)
        val w = width.toFloat(); val h = height.toFloat(); val path = Path()
        data.forEachIndexed { i, v ->
            val x = i * w / (data.size - 1)
            val y = h - 3f - (v.coerceAtMost(top) / top * (h - 6f)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val area = Path(path); area.lineTo(w, h); area.lineTo(0f, h); area.close()
        fill.shader = LinearGradient(0f, 0f, 0f, h, (color and 0x00FFFFFF) or 0x40000000, (color and 0x00FFFFFF) or 0x00000000, Shader.TileMode.CLAMP)
        c.drawPath(area, fill)
        line.color = color; c.drawPath(path, line)
    }
}
