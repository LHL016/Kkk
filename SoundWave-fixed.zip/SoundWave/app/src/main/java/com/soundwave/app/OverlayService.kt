package com.soundwave.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

/**
 * Floating, draggable, resizable monitor drawn over the game (needs "Display over other apps").
 * Header = drag handle, bottom-right corner = resize handle. Minimizes to a small ping bubble.
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private lateinit var panel: FrameLayout
    private lateinit var bubble: TextView
    private lateinit var plp: WindowManager.LayoutParams
    private lateinit var blp: WindowManager.LayoutParams
    private lateinit var rows: LinearLayout
    private lateinit var livePill: TextView
    private lateinit var autoChip: TextView
    private lateinit var pingChip: TextView
    private lateinit var gwChip: TextView
    private lateinit var bannerView: TextView
    private lateinit var statsRow: LinearLayout
    private lateinit var cpuChip: TextView
    private lateinit var ramChip: TextView
    private lateinit var fpsChip: TextView
    private lateinit var tempChip: TextView
    private lateinit var spark: Spark
    private lateinit var tabSrv: TextView
    private lateinit var tabPeer: TextView
    private val presets = listOf(50, 80, 100, 150, 200, 300)
    private var shownView: View? = null
    private var created = false
    private var lastSig = ""
    private var tab = 0                                      // 0 = game servers, 1 = peers
    private var alphaIdx = 0
    private val alphas = floatArrayOf(1f, 0.75f, 0.5f, 0.3f)
    private val scores = HashMap<String, Double>()
    private val lastHits = HashMap<String, Long>()
    private val prefs by lazy { getSharedPreferences("overlay", MODE_PRIVATE) }

    private val WHITE = Color.WHITE
    private val MUTED = Color.parseColor("#A0A0B8")
    private val GREEN = Color.parseColor("#2FBF71")
    private val AMBER = Color.parseColor("#E0A02C")
    private val RED = Color.parseColor("#E05252")
    private val GRAY = Color.parseColor("#6F6F85")

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int { if (!created) create(); return START_NOT_STICKY }
    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        FpsMeter.stop("overlay")
        try { shownView?.let { wm.removeView(it) } } catch (e: Exception) {}
        created = false
        super.onDestroy()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun iconBtn(res: Int, click: () -> Unit) = ImageView(this).apply {
        setImageResource(res); setColorFilter(WHITE); setPadding(dp(6), dp(6), dp(6), dp(6))
        layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)); setOnClickListener { click() }
    }
    private fun params(w: Int, hh: Int) = WindowManager.LayoutParams(
        w, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }
    private fun pingColor(p: Int) = when { p < 0 -> GRAY; p < 80 -> GREEN; p < 150 -> AMBER; else -> RED }
    private fun flag(s: Server) =
        if (s.country.length == 2) s.country.map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("") else "🌐"

    private fun savePos() {
        prefs.edit().putInt("x", plp.x).putInt("y", plp.y).putInt("w", plp.width).putInt("h", plp.height)
            .putInt("a", alphaIdx).apply()
    }

    private fun moveTo(x: Int, y: Int) {
        val m = resources.displayMetrics
        val nx = x.coerceIn(0, maxOf(0, m.widthPixels - dp(48)))
        val ny = y.coerceIn(0, maxOf(0, m.heightPixels - dp(48)))
        plp.x = nx; plp.y = ny; blp.x = nx; blp.y = ny
        shownView?.let { try { wm.updateViewLayout(it, if (it === panel) plp else blp) } catch (e: Exception) {} }
    }

    private fun swap(to: View, lp: WindowManager.LayoutParams) {
        try { shownView?.let { wm.removeView(it) }; wm.addView(to, lp); shownView = to; lastSig = "" } catch (e: Exception) {}
        syncFps()
    }

    /** The frame meter only runs while the full panel is visible and FPS is enabled, so it costs nothing otherwise. */
    private fun syncFps() {
        if (Monitor.ovFps && shownView === panel) FpsMeter.start("overlay", FpsMeter.displayHz(this)) else FpsMeter.stop("overlay")
    }

    private inner class Drag(val onTap: (() -> Unit)?) : View.OnTouchListener {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = plp.x; sy = plp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) moveTo(sx + dx, sy + dy)
                }
                MotionEvent.ACTION_UP -> if (moved) savePos() else onTap?.invoke()
            }
            return true
        }
    }

    private inner class Resize : View.OnTouchListener {
        var sw = 0; var sh = 0; var tx = 0f; var ty = 0f
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sw = plp.width; sh = plp.height; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    val m = resources.displayMetrics
                    plp.width = (sw + (e.rawX - tx)).toInt().coerceIn(dp(250), m.widthPixels)
                    plp.height = (sh + (e.rawY - ty)).toInt().coerceIn(dp(140), m.heightPixels)
                    try { wm.updateViewLayout(panel, plp) } catch (x: Exception) {}
                }
                MotionEvent.ACTION_UP -> savePos()
            }
            return true
        }
    }

    // ---------- building the windows ----------
    private fun create() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        created = true
        alphaIdx = prefs.getInt("a", 0).coerceIn(0, alphas.size - 1)
        plp = params(prefs.getInt("w", dp(330)), prefs.getInt("h", dp(300)))
        plp.x = prefs.getInt("x", dp(16)); plp.y = prefs.getInt("y", dp(48))
        blp = params(dp(52), dp(52)); blp.x = plp.x; blp.y = plp.y
        buildPanel(); buildBubble()
        try { wm.addView(panel, plp); shownView = panel } catch (e: Exception) { stopSelf(); return }
        syncFps()
        h.post(ticker)
    }

    private fun buildPanel() {
        panel = FrameLayout(this).apply { background = rounded(Color.parseColor("#F0161624"), 14); alpha = alphas[alphaIdx] }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(4), dp(4), dp(4)) }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_wave); setColorFilter(Color.parseColor("#7DF3FF")); layoutParams = LinearLayout.LayoutParams(dp(16), dp(16))
        })
        header.addView(tv(APP_NAME, 13f, WHITE, true), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        livePill = tv("–", 12f, WHITE, true).apply { setPadding(dp(8), dp(2), dp(8), dp(2)); background = rounded(GRAY, 12) }
        header.addView(livePill)
        header.addView(iconBtn(R.drawable.ic_opacity) {
            alphaIdx = (alphaIdx + 1) % alphas.size; panel.alpha = alphas[alphaIdx]; bubble.alpha = alphas[alphaIdx]; savePos()
        })
        header.addView(iconBtn(R.drawable.ic_minimize) { swap(bubble, blp) })
        header.addView(iconBtn(R.drawable.ic_close) { stopSelf() })
        header.setOnTouchListener(Drag(null))
        col.addView(header)

        // quick ping filter: tap the ping chip for the next preset, long-press for the previous one
        autoChip = tv("", 11f, WHITE, true).apply {
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { Monitor.autoOn = !Monitor.autoOn; Monitor.save(); refreshBar() }
        }
        pingChip = tv("", 11f, WHITE, true).apply {
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener {
                val next = presets.firstOrNull { it > Monitor.maxPing } ?: presets.first()
                Monitor.maxPing = next; Monitor.save(); refreshBar()
            }
            setOnLongClickListener {
                val prev = presets.lastOrNull { it < Monitor.maxPing } ?: presets.last()
                Monitor.maxPing = prev; Monitor.save(); refreshBar(); true
            }
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(8), dp(4)) }
        bar.addView(autoChip)
        bar.addView(pingChip, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(6) })
        gwChip = tv("", 11f, WHITE, true).apply { setPadding(dp(8), dp(4), dp(8), dp(4)) }
        bar.addView(gwChip, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(6) })
        col.addView(bar)
        // device stats: CPU / RAM / FPS / temperature (each can be switched off in the app)
        fun statChip() = tv("", 10f, WHITE, true).apply { gravity = Gravity.CENTER; setSingleLine(); setPadding(dp(2), dp(3), dp(2), dp(3)) }
        cpuChip = statChip(); ramChip = statChip(); fpsChip = statChip(); tempChip = statChip()
        statsRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(8), dp(4)) }
        for (c in listOf(cpuChip, ramChip, fpsChip, tempChip)) statsRow.addView(c, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        col.addView(statsRow)
        spark = Spark(this)
        col.addView(spark, LinearLayout.LayoutParams(-1, dp(26)).apply { setMargins(dp(10), 0, dp(10), dp(4)) })
        bannerView = tv("", 11f, WHITE, true).apply { setPadding(dp(10), dp(4), dp(10), dp(4)); visibility = View.GONE }
        col.addView(bannerView)

        tabSrv = tv("", 11f, WHITE, true).apply { gravity = Gravity.CENTER; setPadding(dp(6), dp(5), dp(6), dp(5)); setOnClickListener { tab = 0; lastSig = ""; refresh() } }
        tabPeer = tv("", 11f, WHITE, true).apply { gravity = Gravity.CENTER; setPadding(dp(6), dp(5), dp(6), dp(5)); setOnClickListener { tab = 1; lastSig = ""; refresh() } }
        val tabs = LinearLayout(this).apply { setPadding(dp(8), 0, dp(8), dp(4)) }
        tabs.addView(tabSrv, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        tabs.addView(tabPeer, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(tabs)
        rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6), 0, dp(6), dp(24)) }
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(rows) }
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        panel.addView(col, FrameLayout.LayoutParams(-1, -1))

        val handle = ImageView(this).apply { setImageResource(R.drawable.ic_corner); setColorFilter(MUTED); setPadding(dp(4), dp(4), dp(2), dp(2)) }
        handle.setOnTouchListener(Resize())
        panel.addView(handle, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.BOTTOM or Gravity.END))
    }

    private fun buildBubble() {
        bubble = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 13f; setTextColor(WHITE); setTypeface(typeface, Typeface.BOLD)
            text = "–"; alpha = alphas[alphaIdx]
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(GRAY) }
        }
        bubble.setOnTouchListener(Drag { swap(panel, plp) })
    }

    private fun refreshBar() {
        autoChip.text = if (Monitor.autoOn) "Auto ON" else "Auto OFF"
        autoChip.background = rounded(if (Monitor.autoOn) GREEN else GRAY, 12)
        pingChip.text = "≤ ${Monitor.maxPing} ms"
        pingChip.background = rounded(Color.parseColor("#33FFFFFF"), 12)
        pingChip.alpha = if (Monitor.autoOn) 1f else 0.5f
        gwChip.text = if (Monitor.gw.samples() > 0 && Monitor.netType != "Mobile") "${Monitor.netType} ${Monitor.fmt(Monitor.gw.cur())} ms" else Monitor.netType
        gwChip.background = rounded(when (Monitor.netLevel()) { 0 -> GREEN; 1 -> AMBER; 2 -> RED; else -> GRAY }, 12)
    }

    // ---------- live updates ----------
    private val ticker = object : Runnable {
        override fun run() {
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            val min = shownView !== panel
            if (pm.isInteractive) {
                if (!min) SysStats.request(applicationContext)    // device stats only while the full panel is visible
                try { refresh() } catch (e: Exception) {}
            }
            h.postDelayed(this, if (!pm.isInteractive) 5000L else if (min) 2000L else 1000L)
        }
    }

    private fun heat(v: Int, warn: Int, bad: Int) = when { v < 0 -> GRAY; v < warn -> GREEN; v < bad -> AMBER; else -> RED }

    private fun refreshStats() {
        syncFps()
        val anyStat = Monitor.ovCpu || Monitor.ovRam || Monitor.ovFps || Monitor.ovTemp
        statsRow.visibility = if (anyStat) View.VISIBLE else View.GONE
        cpuChip.visibility = if (Monitor.ovCpu) View.VISIBLE else View.GONE
        ramChip.visibility = if (Monitor.ovRam) View.VISIBLE else View.GONE
        fpsChip.visibility = if (Monitor.ovFps) View.VISIBLE else View.GONE
        tempChip.visibility = if (Monitor.ovTemp) View.VISIBLE else View.GONE
        if (Monitor.ovCpu) {
            val c = SysStats.cpuPct
            if (c >= 0) { cpuChip.text = "CPU ${if (SysStats.cpuEstimated) "~" else ""}$c%"; cpuChip.background = rounded(heat(c, 60, 85), 10) }
            else { cpuChip.text = "SW ${Math.round(SysStats.appCpuPct)}%"; cpuChip.background = rounded(GRAY, 10) }   // system CPU hidden by this device: show our own cost
        }
        if (Monitor.ovRam) {
            ramChip.text = "RAM ${SysStats.ramPct}%"
            ramChip.background = rounded(if (SysStats.ramLow) RED else heat(SysStats.ramPct, 75, 90), 10)
        }
        if (Monitor.ovFps) {
            val f = FpsMeter.fps
            fpsChip.text = if (f > 0) "$f FPS" else "FPS –"
            val hz = FpsMeter.refreshHz
            fpsChip.background = rounded(if (f <= 0) GRAY else if (f >= hz * 0.9f) GREEN else if (f >= hz * 0.6f) AMBER else RED, 10)
        }
        if (Monitor.ovTemp) {
            val t = SysStats.battTempC
            tempChip.text = if (t > 0) "${Math.round(t)}°C" else "– °C"
            tempChip.background = rounded(when (SysStats.heatLevel()) { 0 -> GREEN; 1 -> AMBER; 2 -> RED; else -> GRAY }, 10)
        }
    }

    private fun refresh() {
        refreshBar()
        refreshStats()
        val now = System.currentTimeMillis()
        if (now < Monitor.bannerUntil) {
            bannerView.text = Monitor.bannerText
            bannerView.background = rounded(when (Monitor.bannerKind) { 1 -> RED; 2 -> AMBER; else -> Color.parseColor("#4B2BD1") }, 8)
            bannerView.visibility = View.VISIBLE
        } else if (bannerView.visibility != View.GONE) bannerView.visibility = View.GONE
        val list = Monitor.servers.values.filter { (it.hits >= 5 && now - it.lastSeen < 60000) || it.blocked }.sortedByDescending { it.lastSeen }
        val live = Monitor.live
        val srvAll = list.filter { it.kind != 2 }.sortedWith(compareByDescending<Server> { it.near }.thenBy { if (it.samples() > 0) it.recentAvg(3) else 9999 })
        val peerAll = list.filter { it.kind == 2 }.sortedBy { if (it.samples() > 0) it.recentAvg(3) else 9999 }
        val tabList = if (tab == 0) srvAll else peerAll
        val ordered = if (live != null && live in tabList) listOf(live) + tabList.filter { it !== live } else tabList
        tabSrv.text = "Servers (${srvAll.size})"; tabPeer.text = "Peers (${peerAll.size})"
        tabSrv.background = rounded(if (tab == 0) Color.parseColor("#4B2BD1") else Color.parseColor("#33FFFFFF"), 10)
        tabPeer.background = rounded(if (tab == 1) Color.parseColor("#4B2BD1") else Color.parseColor("#33FFFFFF"), 10)

        val lp = if (live != null && live.samples() > 0) live.recentAvg(3) else -1
        val c = pingColor(lp)
        livePill.text = if (lp >= 0) "$lp ms" else "–"
        livePill.background = rounded(c, 12)
        bubble.text = if (lp >= 0) "$lp" else "–"
        (bubble.background as GradientDrawable).setColor(c)

        if (shownView !== panel) return                       // minimized: only the bubble needs updating
        val series = live?.series() ?: emptyList()
        spark.data = series; spark.color = c
        spark.visibility = if (series.size >= 2) View.VISIBLE else View.GONE
        spark.invalidate()
        val top = ordered.take(6)
        val sig = Monitor.running.toString() + "|" + top.joinToString("|") { "$tab${it.ip}:${if (it.samples() > 0) it.recentAvg(3) else -1}:${it.blocked}:${it === live}:${it.lossPct()}" }
        if (sig == lastSig) return                            // nothing changed: skip rebuilding the rows
        lastSig = sig
        rows.removeAllViews()
        if (top.isEmpty()) rows.addView(tv(if (Monitor.running) (if (tab == 0) "Waiting for game server traffic..." else "No peer connections seen") else "Monitoring is off. Tap Start in $APP_NAME.", 12f, MUTED).apply { setPadding(dp(8), dp(12), dp(8), 0) })
        for (s in top) rows.addView(row(s, s === live))
    }

    private fun row(s: Server, isLive: Boolean): View {
        val p = if (s.samples() == 0) -1 else s.recentAvg(3)
        val r = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6))
            if (isLive) background = rounded(Color.parseColor("#26FFFFFF"), 10)
            alpha = if (s.blocked) 0.6f else 1f
            setOnClickListener { Monitor.toggle(s) }
        }
        r.addView(tv(flag(s), 16f, WHITE))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(tv((if (s.near) "★ " else "") + (if (isLive) s.ip + "  LIVE" else s.ip), 12f, if (isLive) GREEN else WHITE, true))
        mid.addView(tv(s.place + (if (s.samples() == 0) " · no reply to ping" else " · jitter ${Monitor.fmt(s.jitterD())} ms · loss ${s.lossPct()}%"), 10f, MUTED))
        r.addView(mid, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        val label = if (s.blocked) "BLOCKED" else if (p < 0) "no ping" else "$p ms"
        r.addView(tv(label, 11f, WHITE, true).apply {
            setPadding(dp(8), dp(2), dp(8), dp(2)); background = rounded(if (s.blocked) RED else pingColor(p), 12)
        })
        return r
    }
}
