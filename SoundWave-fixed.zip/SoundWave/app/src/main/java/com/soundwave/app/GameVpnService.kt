package com.soundwave.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.os.Process
import android.os.VibrationEffect
import android.os.Vibrator
import android.service.quicksettings.TileService
import android.util.Log
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.ConnectException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Routes ONLY the chosen game through a local VPN, relays its traffic to the real servers, and records /
 * filters the UDP servers it talks to. IPv4 only.
 *
 * Hot path (UDP game traffic) is allocation-free: numeric flow keys, last-flow cache, packets built in place.
 */
class GameVpnService : VpnService() {
    companion object {
        const val EXTRA_PKG = "pkg"
        const val ACTION_STOP = "stop"
        const val ACTION_TOGGLE_FILTERS = "toggle_filters"
        const val TAG = "SoundWave"
        private const val CHANNEL = "monitor"
        private const val CH_ALERT = "alerts"
        private const val CH_INFO = "info"
        private const val NOTIF_ID = 7
    }

    private var tun: ParcelFileDescriptor? = null
    private var out: FileOutputStream? = null
    @Volatile private var active = false
    @Volatile private var gen = 0                              // bumped on every start/stop; old worker loops see the change and exit
    private val udp = ConcurrentHashMap<Long, UdpFlow>()
    private val tcp = ConcurrentHashMap<Long, TcpFlow>()
    private val pool = Executors.newCachedThreadPool()

    // caches used only by the TUN reader thread
    private var lastDst = 0
    private var lastServer: Server? = null
    private var lastUdpKey = 0L
    private var lastUdp: UdpFlow? = null
    private var alertedFor: Server? = null
    private var seenEvent = Monitor.eventId
    private var lastSpike = 0L
    private var lastBlockAlert = 0L
    @Volatile private var lastPacketAt = 0L

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Monitor.init(applicationContext)
        when (i?.action) {
            ACTION_STOP -> { stopAll(); stopSelf(); return START_NOT_STICKY }
            ACTION_TOGGLE_FILTERS -> {
                Monitor.filtersEnabled = !Monitor.filtersEnabled; Monitor.save()
                updateNotification(); tiles(); return START_NOT_STICKY
            }
        }
        val pkg = i?.getStringExtra(EXTRA_PKG) ?: return START_NOT_STICKY
        stopAll()
        createChannel()
        Monitor.lastError = ""
        val b = Builder().setSession(APP_NAME).addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0).setMtu(1500).setBlocking(true)   // blocking read: no busy-spinning on an empty tunnel
        // Use the network's own DNS (correct CDN/game-server selection) and fall back to Google DNS only if unknown.
        b.addDnsServer(systemDns() ?: "8.8.8.8")
        if (Monitor.blockV6) {
            // Without an IPv6 route the game's IPv6 traffic would skip the tunnel and dodge every filter.
            // Packets sent into the tunnel are dropped, so the game falls back to IPv4.
            try { b.addAddress("fd00:53:77::2", 128); b.addRoute("::", 0) } catch (e: Exception) { fail("ipv6 route: $e", e) }
        }
        try { b.addAllowedApplication(pkg) } catch (e: Exception) { fail("game not found: $pkg", e); return START_NOT_STICKY }
        val fd = try { b.establish() } catch (e: Exception) { fail("vpn establish: $e", e); null } ?: return START_NOT_STICKY
        tun = fd; out = FileOutputStream(fd.fileDescriptor)
        val g = ++gen
        active = true; Monitor.running = true; Monitor.lastGame = pkg
        lastPacketAt = SystemClock.elapsedRealtime()
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
            readLoop(FileInputStream(fd.fileDescriptor), g)
        }.start()
        Thread { pingLoop(g) }.start()
        Thread { timerLoop(g) }.start()
        updateNotification(); tiles()
        return START_NOT_STICKY
    }

    /** First IPv4 DNS server of the underlying network, or null. */
    private fun systemDns(): String? = try {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.activeNetwork?.let { cm.getLinkProperties(it) }?.dnsServers
            ?.firstOrNull { it is Inet4Address && !it.isAnyLocalAddress }?.hostAddress
    } catch (e: Exception) { null }

    private fun stopAll() {
        active = false; gen++; Monitor.running = false
        Monitor.endSession(System.currentTimeMillis()); Monitor.live = null; alertedFor = null
        if (Monitor.eventId != seenEvent) { seenEvent = Monitor.eventId; showEvent(Monitor.eventKind, Monitor.eventText) }
        udp.values.forEach { it.close() }; tcp.values.forEach { it.close() }
        udp.clear(); tcp.clear(); lastUdp = null; lastServer = null
        for (s in Monitor.servers.values) synchronized(s.held) { s.held.clear(); s.heldCount = 0 }
        try { tun?.close() } catch (e: Exception) {}
        tun = null
        try { getSystemService(NotificationManager::class.java)?.cancel(NOTIF_ID) } catch (e: Exception) {}
        tiles()
    }

    override fun onRevoke() { stopAll(); super.onRevoke() }
    override fun onDestroy() { stopAll(); super.onDestroy() }

    @Synchronized private fun emit(pkt: ByteArray, len: Int = pkt.size) { try { out?.write(pkt, 0, len) } catch (e: Exception) {} }

    private fun fail(msg: String, e: Exception? = null) {
        Monitor.lastError = msg
        if (e != null) Log.w(TAG, msg, e) else Log.w(TAG, msg)
    }

    private fun tiles() {
        try {
            TileService.requestListeningState(this, ComponentName(this, MonitorTile::class.java))
            TileService.requestListeningState(this, ComponentName(this, FilterTile::class.java))
        } catch (e: Exception) {}
    }

    // ---------- notification (the "toggle in the notification panel") ----------
    private fun createChannel() {
        try {
            getSystemService(NotificationManager::class.java)
                ?.apply {
                    createNotificationChannel(NotificationChannel(CHANNEL, "Monitoring", NotificationManager.IMPORTANCE_LOW))
                    createNotificationChannel(NotificationChannel(CH_ALERT, "Alerts", NotificationManager.IMPORTANCE_HIGH))
                    createNotificationChannel(NotificationChannel(CH_INFO, "Match info", NotificationManager.IMPORTANCE_LOW))
                }
        } catch (e: Exception) {}
    }

    private fun updateNotification() {
        if (!active) return
        try {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            val l = Monitor.live
            val text = when {
                l != null && l.samples() > 0 -> "Live: ${Countries.flag(l.country)} ${l.country} ${Monitor.fmt(l.cur())} ms (${Monitor.grade(l)}) · loss ${l.lossPct()}% · ${Monitor.netType}"
                l != null -> "Live: ${l.ip} (measuring ping...)"
                else -> "Waiting for a match..."
            }
            fun pi(action: String, code: Int) = PendingIntent.getService(this, code,
                Intent(this, GameVpnService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_wave)
                .setContentTitle("SoundWave · monitoring").setContentText(text)
                .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open)
                .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stop), "Stop", pi(ACTION_STOP, 1)).build())
                .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_filter),
                    if (Monitor.filtersEnabled) "Filters: ON" else "Filters: OFF", pi(ACTION_TOGGLE_FILTERS, 2)).build())
                .build()
            nm.notify(NOTIF_ID, n)
        } catch (e: Exception) {}
    }

    // ---------- packet loop ----------
    private fun readLoop(inp: FileInputStream, g: Int) {
        val buf = ByteArray(32767)
        try {
            while (active && g == gen) {
                val n = inp.read(buf)
                if (n < 0) break                                  // tunnel closed
                if (n == 0) { try { Thread.sleep(2) } catch (e: Exception) {}; continue }   // safety net if the fd ever reports "no data"
                try { handle(buf, n) } catch (e: Exception) { fail("packet handler: $e", e) }
            }
        } catch (e: Exception) { if (active && g == gen) fail("tun read: $e", e) }
    }

    private fun handle(p: ByteArray, n: Int) {
        if (n < 20 || (p[0].toInt() shr 4) != 4) return         // IPv6 (and anything else) is dropped on purpose
        lastPacketAt = SystemClock.elapsedRealtime()
        val ihl = (p[0].toInt() and 15) * 4
        val total = u16(p, 2)
        if (ihl < 20 || total < ihl || total > n) { fail("bad IP length ihl=$ihl total=$total n=$n"); return }
        if ((u16(p, 6) and 0x3FFF) != 0) { fail("fragmented packet dropped"); return }
        when (p[9].toInt() and 255) {
            17 -> handleUdp(p, total, ihl)
            6 -> handleTcp(p, total, ihl)
        }
    }

    private fun serverFor(dst: Int): Server {
        val c = lastServer
        if (c != null && dst == lastDst) return c
        val s = Monitor.server(ipStr(dst)); lastDst = dst; lastServer = s
        return s
    }

    /** Filter decision, cached for 200 ms per server so the per-packet cost is a couple of field reads. */
    private fun decide(s: Server, now: Long): Boolean {
        if (now - s.okAt > 200) { s.okCache = Monitor.allowed(s); s.okAt = now; if (s.okCache) s.notified = false }
        return s.okCache
    }

    private fun handleUdp(p: ByteArray, total: Int, ihl: Int) {
        if (total < ihl + 8) { fail("short UDP packet"); return }
        val sp = u16(p, ihl); val dp = u16(p, ihl + 2)
        val dst = ip4(p, 16)
        var s: Server? = null
        if (dp != 53) {
            val now = System.currentTimeMillis()
            val sv = serverFor(dst)
            sv.hits++
            if (now - sv.lastSeen > 200) sv.lastSeen = now
            if (dp != sv.port) { sv.port = dp; sv.ports.add(dp) }
            if (!sv.geoStarted && (sv.hits >= 5 || Monitor.needsGeoEarly())) Monitor.lookup(sv)
            // Country filter needs the location first: hold packets (max ~1.5 s) instead of dropping or leaking them.
            if (sv.heldCount > 0 || Monitor.needsGeo(sv)) { hold(sv, dst, p, ihl, total, sp, dp); return }
            if (!decide(sv, now)) {
                // a busy server (the match) got blocked: tell the user once so they can search again
                if (!sv.notified && sv.hits >= 30 && now - lastBlockAlert > 20000) {
                    sv.notified = true; lastBlockAlert = now
                    Monitor.pushEvent(1, "Blocked ${Countries.flag(sv.country)} ${sv.country} ${sv.ip}: ${Monitor.reason(sv) ?: "filter"}. Search for another match.")
                }
                return
            }                       // blocked: drop outbound
            s = sv
        }
        var f = if (flowKey(sp, dst, dp) == lastUdpKey) lastUdp else null
        if (f == null || f.dead) {
            val k = flowKey(sp, dst, dp)
            f = udpFlow(k, dst, sp, dp, s); lastUdpKey = k; lastUdp = f
        }
        f.send(p, ihl + 8, total - ihl - 8)
    }

    private fun udpFlow(k: Long, dst: Int, sp: Int, dp: Int, s: Server?): UdpFlow = synchronized(udp) {
        val e = udp[k]
        if (e != null && !e.dead) e else UdpFlow(k, dst, sp, dp, s).also { udp[k] = it }
    }

    private fun hold(s: Server, dst: Int, p: ByteArray, ihl: Int, total: Int, sp: Int, dp: Int) {
        synchronized(s.held) {
            if (s.held.isEmpty()) s.heldSince = System.currentTimeMillis()
            if (s.held.size < 24) s.held.add(Held(sp, dp, dst, p.copyOfRange(ihl + 8, total)))
            s.heldCount = s.held.size
        }
    }

    /** Releases held packets once the server's location is known (or after 1.5 s, fail-open). */
    private fun flushHeld(now: Long) {
        for (s in Monitor.servers.values) {
            if (s.heldCount == 0) continue
            val waiting = Monitor.needsGeo(s)
            if (waiting && now - s.heldSince < 1500) continue
            if (waiting) s.geoWaitDone = true
            val list = synchronized(s.held) { val c = ArrayList(s.held); s.held.clear(); s.heldCount = 0; c }
            s.okAt = 0L
            if (!Monitor.allowed(s)) continue
            for (h in list) udpFlow(flowKey(h.sp, h.dst, h.dp), h.dst, h.sp, h.dp, s).send(h.data, 0, h.data.size)
        }
    }

    private fun handleTcp(p: ByteArray, total: Int, ihl: Int) {
        if (total < ihl + 20) { fail("short TCP packet"); return }
        val off = ((p[ihl + 12].toInt() shr 4) and 15) * 4
        if (off < 20 || total < ihl + off) { fail("bad TCP header length"); return }
        val sp = u16(p, ihl); val dp = u16(p, ihl + 2); val dst = ip4(p, 16)
        val flags = p[ihl + 13].toInt() and 255
        val seq = u32(p, ihl + 4); val ack = u32(p, ihl + 8)
        val len = total - ihl - off
        val k = flowKey(sp, dst, dp)

        if ((flags and 2) != 0 && (flags and 16) == 0) {          // SYN
            val old = tcp[k]
            if (old != null) {
                if (old.irs == seq) { old.resendSynAck(); return }  // retransmitted SYN
                old.close(); tcp.remove(k, old)                     // port reused: replace stale flow
            }
            val f = TcpFlow(k, ipBytes(dst), sp, dp, seq)
            tcp[k] = f
            val ds = ipStr(dst)
            pool.execute { f.open(ds) }
            return
        }

        val f = tcp[k]
        if (f == null) {                                           // unknown flow
            if ((flags and 4) == 0) {
                if (len > 0) emit(buildTcp(ipBytes(dst), CLIENT, dp, sp, ack and MASK, (seq + len) and MASK, 0x14, null, 0, false))
                else if ((flags and 1) != 0) emit(buildTcp(ipBytes(dst), CLIENT, dp, sp, ack and MASK, (seq + 1) and MASK, 0x10, null, 0, false))
            }
            return
        }
        if ((flags and 4) != 0) { f.close(); return }              // RST
        if ((flags and 16) != 0) f.onAck(ack, u16(p, ihl + 14), len == 0 && (flags and 1) == 0)
        if (!f.established) return
        if (len > 0) {
            if (seq == f.cNext) { f.cNext = (seq + len) and MASK; f.toServer(p, ihl + off, len) }
            f.send(0x10, null, 0)                                  // ACK (a duplicate ACK if out of order)
        }
        if ((flags and 1) != 0) {                                  // FIN
            if (((seq + len) and MASK) == f.cNext) { f.cNext = (f.cNext + 1) and MASK; f.halfClose() }
            f.send(0x10, null, 0)
        }
    }

    // ---------- background work ----------
    /** New servers are pinged at once; the live server every 2.5 s; others every 10 s; servers that ignore ping every 30 s. */
    private fun pingLoop(g: Int) {
        var n = 0
        while (active && g == gen) {
            val now = System.currentTimeMillis()
            val live = Monitor.live
            for (s in Monitor.servers.values) {
                s.flushPassive(now)
                if (s.hits < 5 || now - s.lastSeen > 15000 || s.pinging) continue
                val every = when {
                    s === live -> 2500L
                    s === live && s.samples() == 0 -> 4000L                  // match just started and no answer yet: retry quickly
                    s.samples() == 0 && s.noReply >= 2 -> if (s.kind == 2) 60000L else 30000L
                    s.kind == 2 -> 15000L                                   // peers: slower, they move around and cost battery
                    else -> 10000L
                }
                if (now - s.lastPing >= every) {
                    s.pinging = true; s.lastPing = now
                    pool.execute { try { ping(s) } finally { s.pinging = false } }
                }
            }
            if (++n % 3 == 0) { pool.execute { pingGateway() }; updateNotification() }
            // screen off: nobody is looking, so measure less often (the game keeps running in the tunnel)
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            try { Thread.sleep(if (pm.isInteractive) 1000L else 4000L) } catch (e: Exception) {}
        }
    }

    private fun timerLoop(g: Int) {
        var tick = 0
        while (active && g == gen) {
            val now = System.currentTimeMillis()
            flushHeld(now)
            if (tick % 5 == 0) for (f in tcp.values) try { f.checkTimer(now) } catch (e: Exception) {}
            if (Monitor.eventId != seenEvent) { seenEvent = Monitor.eventId; showEvent(Monitor.eventKind, Monitor.eventText) }
            if (tick % 20 == 0) {
                try { Monitor.updateLive(now); haptic(); checkSpike(now) } catch (e: Exception) {}
                val idle = Monitor.idleStopMin
                if (idle > 0 && SystemClock.elapsedRealtime() - lastPacketAt > idle * 60000L) {
                    postNote(CH_INFO, 12, "SoundWave stopped", "No game traffic for $idle min, so monitoring was turned off.")
                    stopAll(); stopSelf(); return
                }
            }
            tick++
            try { Thread.sleep(50) } catch (e: Exception) {}
        }
    }

    private fun buzz(pattern: LongArray) {
        if (!Monitor.haptics) return
        try { (getSystemService(VIBRATOR_SERVICE) as? Vibrator)?.vibrate(VibrationEffect.createWaveform(pattern, -1)) } catch (e: Exception) {}
    }

    private fun postNote(ch: String, id: Int, title: String, text: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            nm.notify(id, Notification.Builder(this, ch).setSmallIcon(R.drawable.ic_wave).setContentTitle(title).setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(open).build())
        } catch (e: Exception) {}
    }

    /** 1 = server blocked (heads-up + buzz), 2 = lag spike (buzz), 3 = match summary. The overlay shows a banner for all three. */
    private fun showEvent(kind: Int, text: String) {
        when (kind) {
            1 -> { buzz(longArrayOf(0, 150, 80, 150, 80, 250)); postNote(CH_ALERT, 9, "Server blocked", text) }
            2 -> { buzz(longArrayOf(0, 90, 60, 90)); postNote(CH_INFO, 10, "Lag spike", text) }
            else -> postNote(CH_INFO, 11, "Match summary", text)
        }
    }

    /** Lag spike on the live server (not in its first 10 s): say whether it is the server or your own network. */
    private fun checkSpike(now: Long) {
        val l = Monitor.live ?: return
        if (l.samples() < 4 || now - lastSpike < 20000 || now - Monitor.liveSince < 10000) return
        val c = l.cur()
        if (c > 60 && c > Monitor.maxPing * 1.3) {
            lastSpike = now
            Monitor.pushEvent(2, "Lag spike: ${Countries.flag(l.country)} ${Monitor.fmt(c)} ms. ${Monitor.netText()}")
        }
    }

    /** One short buzz = new match server within your ping limit, double buzz = over it. */
    private fun haptic() {
        if (!Monitor.haptics) return
        val l = Monitor.live ?: return
        if (l === alertedFor || l.samples() == 0) return
        alertedFor = l
        val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
        val bad = l.cur() > Monitor.maxPing
        v.vibrate(VibrationEffect.createWaveform(if (bad) longArrayOf(0, 120, 90, 120) else longArrayOf(0, 45), -1))
    }

    /** Pings the router so Wi-Fi lag can be told apart from server lag. Not available on mobile data. */
    @Volatile private var gwBusy = false

    private fun pingGateway() {
        if (gwBusy) return                                       // a slow router must not stack up probes
        gwBusy = true
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork
            val caps = net?.let { cm.getNetworkCapabilities(it) }
            Monitor.netType = when {
                caps == null -> "Offline"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
                else -> "Network"
            }
            val gw = net?.let { cm.getLinkProperties(it) }?.routes
                ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress
            Monitor.gwIp = gw ?: ""
            if (gw == null || Monitor.netType == "Mobile") return
            val got = times(runPing(listOf("ping", "-c", "4", "-i", "0.2", "-W", "1", gw)))
            got.forEach { Monitor.gw.addRtt(it) }
            for (i in 1..4) Monitor.gw.addProbe(i <= got.size)
        } catch (e: Exception) {
        } finally { gwBusy = false }
    }

    /** Runs ping and always reaps the process; a watchdog kills it if it hangs, so a stuck probe can't block a server forever. */
    private fun runPing(cmd: List<String>): String {
        val pr = ProcessBuilder(cmd).redirectErrorStream(true).start()
        val killer = Thread {
            try { Thread.sleep(10000); pr.destroyForcibly() } catch (e: InterruptedException) {}
        }.apply { isDaemon = true; start() }
        try {
            val text = pr.inputStream.bufferedReader().readText()
            pr.waitFor()
            return text
        } finally {
            killer.interrupt(); pr.destroy()
        }
    }

    private fun times(t: String) = Regex("time[=<]([0-9.]+)").findAll(t).map { it.groupValues[1].toDouble() }.toList()

    /** 4 probes 0.2 s apart; falls back to a single probe if -i is unsupported. */
    private fun ping(s: Server) {
        try {
            val out = runPing(listOf("ping", "-c", "4", "-i", "0.2", "-W", "1", "-w", "6", s.ip))
            var got = times(out); var sent = 4
            if (got.isEmpty() && !out.contains("packet loss")) {
                got = times(runPing(listOf("ping", "-c", "1", "-W", "2", s.ip))); sent = 1
            }
            if (got.isNotEmpty()) s.via = "ICMP"
            else {
                // Many game servers drop ICMP. Fall back to timing a TCP handshake instead.
                val (tg, attempts) = tcpProbe(s)
                if (tg.isNotEmpty()) { got = tg; sent = attempts; s.via = "TCP" }
            }
            Monitor.onBurst(s, got, sent)
        } catch (e: Exception) {}
    }

    /**
     * TCP round-trip probe for servers that ignore ICMP. A completed handshake or a refused connection (RST) both
     * prove the server answered, so the connect time is a valid RTT. A timeout means filtered/dropped (no sample).
     * The socket is protect()ed, so it bypasses the tunnel and is never mistaken for game traffic.
     * Returns (RTT samples in ms, attempts made).
     */
    private fun tcpProbe(s: Server, n: Int = 4): Pair<List<Double>, Int> {
        val rtts = ArrayList<Double>()
        var attempts = 0
        for (port in intArrayOf(443, 80)) {
            var tries = 0
            while (active && rtts.size < n && tries < n) {
                tries++; attempts++
                val sock = Socket()
                try {
                    sock.bind(null); protect(sock)
                    val t0 = System.nanoTime()
                    var answered = true
                    try { sock.connect(InetSocketAddress(s.ip, port), 1500) }
                    catch (e: ConnectException) { answered = e.message?.contains("refused", true) == true }
                    catch (e: SocketTimeoutException) { answered = false }
                    catch (e: Exception) { answered = false }
                    if (answered) rtts.add((System.nanoTime() - t0) / 1e6) else break   // port filtered: try the next port
                } finally { try { sock.close() } catch (e: Exception) {} }
                try { Thread.sleep(200) } catch (e: Exception) { break }
            }
            if (rtts.isNotEmpty()) break
        }
        return rtts to attempts
    }

    // ---------- flows ----------
    inner class UdpFlow(val key: Long, val dst: Int, val cPort: Int, val sPort: Int, val server: Server?) {
        @Volatile var dead = false
        private val sock = DatagramSocket()
        init {
            protect(sock)
            sock.connect(InetAddress.getByAddress(ipBytes(dst)), sPort)
            sock.soTimeout = 120000
            pool.execute {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
                val b = ByteArray(28 + 1500)                       // payload lands at offset 28, headers are filled in place
                val pk = DatagramPacket(b, 28, 1500)
                try {
                    while (active && !dead) {
                        pk.length = 1500
                        sock.receive(pk)
                        if (server != null && !decide(server, System.currentTimeMillis())) continue   // blocked: drop inbound too
                        if (server != null) server.notePassive()
                        val len = pk.length
                        fillUdpHeader(b, dst, cPort, sPort, len)
                        emit(b, 28 + len)
                    }
                } catch (e: Exception) {}
                dead = true; sock.close(); udp.remove(key, this@UdpFlow)
            }
        }
        fun send(d: ByteArray, off: Int, len: Int) { server?.let { if (it.sendNs == 0L) it.sendNs = System.nanoTime() }; try { sock.send(DatagramPacket(d, off, len)) } catch (e: Exception) {} }
        fun close() { dead = true; sock.close() }
    }

    private class Seg(val seq: Long, val data: ByteArray)

    /**
     * One relayed TCP connection. Our side's sequence numbers are absolute Longs starting at iss; cAck is the
     * highest byte of OUR stream the client has acknowledged (seq - cAck = bytes in flight); cNext is the next
     * byte expected from the client (32-bit).
     */
    inner class TcpFlow(val key: Long, val sIp: ByteArray, val cPort: Int, val sPort: Int, val irs: Long) {
        private val cIp = CLIENT
        @Volatile var cNext = (irs + 1) and MASK
        @Volatile var cAck = 0L
        @Volatile var cWin = 65535
        @Volatile var closed = false
        @Volatile var established = false
        private val iss = 1000L + (Math.random() * 1000000).toLong()
        @Volatile private var seq = iss
        private val unacked = ArrayDeque<Seg>()
        private var dupAcks = 0
        private var retries = 0
        private var lastSend = 0L
        private var sock: Socket? = null
        private val wq = LinkedBlockingQueue<ByteArray>()
        private val finMark = ByteArray(0)

        init { cAck = iss }

        @Synchronized fun send(flags: Int, d: ByteArray?, len: Int, syn: Boolean = false) {
            if (closed && (flags and 4) == 0) return
            emit(buildTcp(sIp, cIp, sPort, cPort, seq and MASK, cNext and MASK, flags, d, len, syn))
            if (len > 0 && d != null) { unacked.addLast(Seg(seq, d.copyOf(len))); lastSend = System.currentTimeMillis() }
            seq += len + (if ((flags and 3) != 0) 1 else 0)
        }

        @Synchronized fun resendSynAck() {
            if (established) emit(buildTcp(sIp, cIp, sPort, cPort, iss and MASK, (irs + 1) and MASK, 0x12, null, 0, true))
        }

        @Synchronized fun onAck(ack32: Long, win: Int, pure: Boolean) {
            cWin = win
            val a = unwrap(ack32, seq)
            if (a < iss || a > seq) return
            if (a > cAck) {
                cAck = a; dupAcks = 0; retries = 0
                while (unacked.isNotEmpty() && unacked.first().seq + unacked.first().data.size <= a) unacked.removeFirst()
            } else if (pure && a == cAck && unacked.isNotEmpty() && ++dupAcks == 3) retransmit()
        }

        private fun retransmit() {
            val s = unacked.firstOrNull() ?: return
            emit(buildTcp(sIp, cIp, sPort, cPort, s.seq and MASK, cNext and MASK, 0x18, s.data, s.data.size, false))
            lastSend = System.currentTimeMillis()
        }

        @Synchronized fun checkTimer(now: Long) {
            if (unacked.isEmpty() || now - lastSend < 600) return
            if (++retries > 12) { close(); return }
            retransmit()
        }

        @Synchronized private fun pending() = unacked.size

        fun open(dst: String) {
            try {
                val s = Socket(); s.bind(null); protect(s)
                s.connect(InetSocketAddress(dst, sPort), 5000)
                s.tcpNoDelay = true; s.soTimeout = 600000
                sock = s
                startWriter(s)
                established = true
                send(0x12, null, 0, true)                            // SYN|ACK
                val inp = s.getInputStream(); val buf = ByteArray(1360)
                while (!closed) {
                    val n = inp.read(buf); if (n < 0) break
                    while (!closed && seq - cAck >= minOf(cWin, 60000)) Thread.sleep(2)   // honour client window
                    if (closed) break
                    send(0x18, buf, n)                               // PSH|ACK
                }
                if (!closed) {
                    send(0x11, null, 0)                              // FIN|ACK
                    val t0 = System.currentTimeMillis()              // linger so unacked data can be retransmitted
                    while (!closed && pending() > 0 && System.currentTimeMillis() - t0 < 5000) Thread.sleep(20)
                }
            } catch (e: Exception) {
                if (!closed) {
                    // A connect timeout/refusal is the remote host's normal behaviour, not a SoundWave fault: log it only.
                    if (e is java.io.IOException) Log.w(TAG, "tcp $key: $e") else fail("tcp $key: $e")
                    send(0x14, null, 0)                          // RST|ACK
                }
            } finally {
                closed = true; tcp.remove(key, this)
                try { sock?.close() } catch (e: Exception) {}
            }
        }

        private fun startWriter(s: Socket) {
            pool.execute {
                try {
                    val os = s.getOutputStream()
                    while (!closed) {
                        val d = wq.poll(500, TimeUnit.MILLISECONDS) ?: continue
                        if (d === finMark) { s.shutdownOutput(); break }
                        os.write(d)
                    }
                } catch (e: Exception) { close() }
            }
        }

        fun toServer(d: ByteArray, off: Int, len: Int) { wq.offer(d.copyOfRange(off, off + len)) }
        fun halfClose() { wq.offer(finMark) }
        fun close() { closed = true; try { sock?.close() } catch (e: Exception) {} }
    }
}

// ---------- raw IPv4 packet helpers ----------
private val CLIENT = byteArrayOf(10, 8, 0, 2)
private const val MASK = 0xFFFFFFFFL

private fun flowKey(sp: Int, dst: Int, dp: Int): Long = (sp.toLong() shl 48) or (dp.toLong() shl 32) or (dst.toLong() and 0xFFFFFFFFL)
private fun ipStr(v: Int) = "${v ushr 24}.${(v shr 16) and 255}.${(v shr 8) and 255}.${v and 255}"
private fun ipBytes(v: Int) = byteArrayOf((v ushr 24).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte())
private fun ip4(b: ByteArray, o: Int) =
    ((b[o].toInt() and 255) shl 24) or ((b[o + 1].toInt() and 255) shl 16) or ((b[o + 2].toInt() and 255) shl 8) or (b[o + 3].toInt() and 255)

private fun unwrap(v: Long, ref: Long): Long {
    var a = v + (ref and MASK.inv())
    if (a < ref - (1L shl 31)) a += 1L shl 32 else if (a > ref + (1L shl 31)) a -= 1L shl 32
    return a
}

private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
private fun u32(b: ByteArray, o: Int): Long = (u16(b, o).toLong() shl 16) or u16(b, o + 2).toLong()
private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = (v shr 8).toByte(); b[o + 1] = v.toByte() }
private fun put32(b: ByteArray, o: Int, v: Long) { put16(b, o, (v shr 16).toInt() and 0xFFFF); put16(b, o + 2, v.toInt() and 0xFFFF) }

private fun csum(b: ByteArray, off: Int, len: Int, init: Long = 0): Int {
    var s = init; var i = off; val end = off + len
    while (i + 1 < end) { s += u16(b, i); i += 2 }
    if (i < end) s += (b[i].toInt() and 255) shl 8
    while ((s shr 16) != 0L) s = (s and 0xFFFF) + (s shr 16)
    return s.inv().toInt() and 0xFFFF
}

private fun ipHeader(p: ByteArray, total: Int, proto: Int, src: ByteArray, dst: ByteArray) {
    p[0] = 0x45; put16(p, 2, total); p[8] = 64; p[9] = proto.toByte()
    System.arraycopy(src, 0, p, 12, 4); System.arraycopy(dst, 0, p, 16, 4)
    put16(p, 10, csum(p, 0, 20))
}

/** Builds the IPv4+UDP header for a server->app datagram whose payload is already at offset 28. */
private fun fillUdpHeader(p: ByteArray, srv: Int, cPort: Int, sPort: Int, len: Int) {
    val total = 28 + len
    p[0] = 0x45; p[1] = 0; put16(p, 2, total); put16(p, 4, 0); put16(p, 6, 0); p[8] = 64; p[9] = 17
    put16(p, 10, 0)
    p[12] = (srv ushr 24).toByte(); p[13] = (srv shr 16).toByte(); p[14] = (srv shr 8).toByte(); p[15] = srv.toByte()
    p[16] = 10; p[17] = 8; p[18] = 0; p[19] = 2
    put16(p, 10, csum(p, 0, 20))
    put16(p, 20, sPort); put16(p, 22, cPort); put16(p, 24, 8 + len); put16(p, 26, 0)   // UDP checksum 0 = none (valid on IPv4)
}

private fun buildTcp(src: ByteArray, dst: ByteArray, sp: Int, dp: Int, seq: Long, ack: Long,
                     flags: Int, d: ByteArray?, len: Int, syn: Boolean): ByteArray {
    val hl = if (syn) 24 else 20
    val tl = hl + len
    val p = ByteArray(20 + tl)
    ipHeader(p, 20 + tl, 6, src, dst)
    put16(p, 20, sp); put16(p, 22, dp); put32(p, 24, seq); put32(p, 28, ack)
    p[32] = ((hl / 4) shl 4).toByte(); p[33] = flags.toByte(); put16(p, 34, 65535)
    if (syn) { p[40] = 2; p[41] = 4; put16(p, 42, 1360) }          // MSS option
    if (d != null) System.arraycopy(d, 0, p, 20 + hl, len)
    val init = (u16(src, 0) + u16(src, 2) + u16(dst, 0) + u16(dst, 2) + 6 + tl).toLong()
    put16(p, 36, csum(p, 20, tl, init))
    return p
}
