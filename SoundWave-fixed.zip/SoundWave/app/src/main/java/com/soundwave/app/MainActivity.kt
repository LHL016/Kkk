package com.soundwave.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private var dark = false                       // follows the system light/dark setting (set in onCreate)
    private fun pal(light: String, night: String) = Color.parseColor(if (dark) night else light)
    private val PURPLE get() = pal("#3D2FB5", "#7B6CF6")
    private val GREEN get() = pal("#1F8A4C", "#2FBF71")
    private val AMBER get() = pal("#B7791F", "#E0A02C")
    private val RED get() = pal("#C53030", "#E05252")
    private val GRAY get() = pal("#7A7A8C", "#9A9AB0")
    private val INK get() = pal("#1D1B2E", "#ECECF6")
    private val BG get() = pal("#F1F2F8", "#0F0F1A")
    private val CARD get() = pal("#FFFFFF", "#1B1B2B")
    private val SOFT get() = pal("#EEF0F8", "#2A2A40")      // unselected chips
    private val TRACK get() = pal("#E4E5EF", "#232336")     // tab bar / segmented control background

    private var apps = listOf<Pair<String, String>>()
    private lateinit var spin: Spinner
    private lateinit var startBtn: Button
    private lateinit var playBtn: Button
    private lateinit var chip: TextView
    private lateinit var status: TextView
    private lateinit var tabServers: TextView
    private lateinit var tabFilters: TextView
    private lateinit var tabHistory: TextView
    private lateinit var tabStats: TextView
    private lateinit var statsView: ScrollView
    private lateinit var historyView: ScrollView
    private lateinit var historyBox: LinearLayout
    private lateinit var netDot: View
    private lateinit var netLine1: TextView
    private lateinit var netLine2: TextView
    private var histSig = ""
    private var listSig = ""
    private lateinit var statsBox: LinearLayout
    private lateinit var serversView: View
    private lateinit var filtersView: ScrollView
    private lateinit var filtersBox: LinearLayout
    private lateinit var empty: View
    private var seenBox: LinearLayout? = null
    private var seenSig = ""
    private var tab = 0
    private var shown = listOf<Server>()
    private var pendingPlay = false
    private val h = Handler(Looper.getMainLooper())
    private val hintText = "Tap a server to block it, or to allow a blocked one anyway. Rules apply to the whole IP. Location is approximate."

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View = rowFor(shown[i])
    }

    // ---------- view helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(2), stroke)
    }
    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun iconView(res: Int, color: Int, size: Int) = ImageView(this).apply {
        setImageResource(res); setColorFilter(color); layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    }
    private fun ic(res: Int, color: Int): Drawable {
        val d = getDrawable(res)!!.mutate(); d.setTint(color); d.setBounds(0, 0, dp(20), dp(20)); return d
    }
    private fun lp(top: Int = 0, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = dp(top) }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = rounded(CARD, 16); setPadding(dp(14), dp(14), dp(14), dp(14))
    }
    private fun fieldRow(res: Int, inner: View): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; background = rounded(BG, 12); setPadding(dp(12), dp(4), dp(8), dp(4))
        addView(iconView(res, PURPLE, 20))
        addView(inner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
    }
    private fun infoRow(res: Int, text: String, color: Int = GRAY): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(iconView(res, color, 14))
        addView(tv(text, 12f, color), LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(6) })
    }
    private fun sectionTitle(res: Int, text: String): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(iconView(res, PURPLE, 18))
        addView(tv(text, 15f, INK, true), LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
    }
    private fun chipView(label: String, selected: Boolean, click: () -> Unit) = tv(label, 13f, if (selected) Color.WHITE else INK, selected).apply {
        background = rounded(if (selected) PURPLE else SOFT, 20)
        setPadding(dp(12), dp(7), dp(12), dp(7)); setOnClickListener { click() }
    }
    private fun chipRow(items: List<Pair<String, Boolean>>, onClick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        items.forEachIndexed { i, (label, sel) ->
            row.addView(chipView(label, sel) { onClick(i) }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        val hs = HorizontalScrollView(this); hs.isHorizontalScrollBarEnabled = false; hs.addView(row); return hs
    }
    private fun segmented(labels: List<String>, sel: Int, onSel: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { background = rounded(TRACK, 12); setPadding(dp(3), dp(3), dp(3), dp(3)) }
        labels.forEachIndexed { i, l ->
            val t = tv(l, 13f, if (i == sel) Color.WHITE else INK, true).apply {
                gravity = Gravity.CENTER; if (i == sel) background = rounded(PURPLE, 10); setOnClickListener { onSel(i) }
            }
            box.addView(t, LinearLayout.LayoutParams(0, dp(36), 1f))
        }
        return box
    }
    private fun switchRow(title: String, sub: String, on: Boolean, cb: (Boolean) -> Unit): View {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(tv(title, 14f, INK, true)); t.addView(tv(sub, 11f, GRAY))
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(Switch(this).apply { isChecked = on; setOnCheckedChangeListener { _, v -> cb(v) } })
        return r
    }
    private fun label(text: String) = tv(text, 12f, GRAY, true)

    // ---------- screen ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        dark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        Monitor.init(applicationContext)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 3)
        window.statusBarColor = BG; window.navigationBarColor = BG
        window.decorView.systemUiVisibility =
            if (dark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)

        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(q, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }                     // don't offer SoundWave itself as the game
            .distinct().sortedBy { it.first.lowercase() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(16), dp(16), dp(16), dp(8))
        }

        // header
        val logo = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#0E0C30"), Color.parseColor("#4B2BD1"), Color.parseColor("#00B8FF")))
                .apply { cornerRadius = dp(12).toFloat() }
        }
        logo.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground) },
            FrameLayout.LayoutParams(dp(46), dp(46), Gravity.CENTER))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(tv(APP_NAME, 22f, INK, true)); titles.addView(tv("Ping · servers · performance", 12f, GRAY))
        chip = tv("Idle", 12f, GRAY, true).apply { setPadding(dp(10), dp(4), dp(10), dp(4)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        head.addView(chip)
        root.addView(head, lp(0))

        // controls
        spin = Spinner(this)
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, apps.map { it.first })
        val saved = apps.indexOfFirst { it.second == Monitor.lastGame }
        if (saved >= 0) spin.setSelection(saved)
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                apps.getOrNull(pos)?.let { Monitor.lastGame = it.second; Monitor.save() }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        startBtn = Button(this).apply {
            isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE); compoundDrawablePadding = dp(6)
            minWidth = 0; minimumWidth = 0; setPadding(dp(8), 0, dp(8), 0); setOnClickListener { toggle() }
        }
        playBtn = Button(this).apply {
            isAllCaps = false; textSize = 14f; setTextColor(PURPLE); compoundDrawablePadding = dp(6)
            minWidth = 0; minimumWidth = 0; setPadding(dp(8), 0, dp(8), 0)
            text = "Play + overlay"; background = rounded(CARD, 14, PURPLE)
            setCompoundDrawablesRelative(ic(R.drawable.ic_overlay, PURPLE), null, null, null)
            setOnClickListener { play() }
        }
        val btns = LinearLayout(this)
        btns.addView(startBtn, LinearLayout.LayoutParams(0, dp(48), 1f))
        btns.addView(playBtn, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        val controls = card()
        controls.addView(fieldRow(R.drawable.ic_game, spin), lp(0))
        controls.addView(btns, lp(10))
        root.addView(controls, lp(14))

        // tabs
        tabServers = tv("Servers", 12f, PURPLE, true).apply { gravity = Gravity.CENTER; setSingleLine(); setOnClickListener { setTab(0) } }
        tabStats = tv("Stats", 12f, GRAY, true).apply { gravity = Gravity.CENTER; setSingleLine(); setOnClickListener { setTab(1) } }
        tabHistory = tv("History", 12f, GRAY, true).apply { gravity = Gravity.CENTER; setSingleLine(); setOnClickListener { setTab(2) } }
        tabFilters = tv("Filters", 12f, GRAY, true).apply { gravity = Gravity.CENTER; setSingleLine(); setOnClickListener { setTab(3) } }
        val tabs = LinearLayout(this).apply { background = rounded(TRACK, 14); setPadding(dp(3), dp(3), dp(3), dp(3)) }
        tabs.addView(tabServers, LinearLayout.LayoutParams(0, dp(38), 1.35f))
        tabs.addView(tabStats, LinearLayout.LayoutParams(0, dp(38), 1f))
        tabs.addView(tabHistory, LinearLayout.LayoutParams(0, dp(38), 1f))
        tabs.addView(tabFilters, LinearLayout.LayoutParams(0, dp(38), 1.1f))
        root.addView(tabs, lp(12))

        // servers tab
        val list = ListView(this).apply {
            divider = null; dividerHeight = 0; setPadding(0, dp(10), 0, dp(8)); clipToPadding = false
            setSelector(android.R.color.transparent)
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, i, _ -> shown.getOrNull(i)?.let { Monitor.toggle(it) } }
        val emptyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        emptyBox.addView(iconView(R.drawable.ic_signal, Color.parseColor("#B8B8C8"), 44))
        emptyBox.addView(tv("No servers yet", 15f, GRAY, true), lp(8))
        emptyBox.addView(tv("Start monitoring, open the game, then search for a match.", 12f, GRAY).apply { gravity = Gravity.CENTER }, lp(2))
        empty = emptyBox
        val sFrame = FrameLayout(this)
        sFrame.addView(list, FrameLayout.LayoutParams(-1, -1))
        sFrame.addView(emptyBox, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        netDot = View(this)
        netLine1 = tv("Network: measuring...", 13f, INK, true)
        netLine2 = tv("", 11f, GRAY)
        val netTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        netTexts.addView(netLine1); netTexts.addView(netLine2)
        val netCard = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = rounded(CARD, 14); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        netCard.addView(netDot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(10) })
        netCard.addView(netTexts, LinearLayout.LayoutParams(0, -2, 1f))
        val sCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sCol.addView(netCard, lp(10))
        sCol.addView(sFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        serversView = sCol

        // filters tab
        filtersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(16)) }
        filtersView = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(filtersBox) }
        historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(16)) }
        historyView = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(historyBox) }

        statsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(16)) }
        statsView = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(statsBox) }
        buildStats()

        val content = FrameLayout(this)
        content.addView(serversView, FrameLayout.LayoutParams(-1, -1))
        content.addView(statsView, FrameLayout.LayoutParams(-1, -1))
        content.addView(historyView, FrameLayout.LayoutParams(-1, -1))
        content.addView(filtersView, FrameLayout.LayoutParams(-1, -1))
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        status = tv("", 11f, GRAY)
        root.addView(status, lp(4))

        setContentView(root)
        buildFilters()
        setTab(0)
        tick()
    }

    private fun setTab(i: Int) {
        tab = i
        listOf(tabServers, tabStats, tabHistory, tabFilters).forEachIndexed { k, t ->
            t.setTextColor(if (k == i) PURPLE else GRAY); t.background = if (k == i) rounded(CARD, 11) else null
        }
        serversView.visibility = if (i == 0) View.VISIBLE else View.GONE
        statsView.visibility = if (i == 1) View.VISIBLE else View.GONE
        historyView.visibility = if (i == 2) View.VISIBLE else View.GONE
        filtersView.visibility = if (i == 3) View.VISIBLE else View.GONE
        if (i == 2) { histSig = ""; refreshHistory() }
        syncFps()
        if (i == 1) { SysStats.request(applicationContext); updateStats() }
    }

    // ---------- filters tab ----------
    private fun changed() { Monitor.save(); buildFilters() }

    private fun buildFilters() {
        val b = filtersBox
        b.removeAllViews(); seenBox = null; seenSig = ""

        // Master switch
        val c0 = card()
        c0.addView(switchRow("Filters", if (Monitor.filtersEnabled) "Country and auto filters are active" else "Paused: only your own blocks apply", Monitor.filtersEnabled) {
            Monitor.filtersEnabled = it; changed()
        })
        b.addView(c0, lp(0))

        // Country filter
        val c1 = card()
        c1.addView(sectionTitle(R.drawable.ic_public, "Country filter"))
        val mode = Monitor.countryMode
        c1.addView(segmented(listOf("Off", "Allow only", "Block"), mode.ordinal) { i ->
            Monitor.countryMode = CountryMode.values()[i]; changed()
        }, lp(10))
        val blurb = when (mode) {
            CountryMode.OFF -> "Every country is allowed."
            CountryMode.ALLOW -> if (Monitor.countries.isEmpty()) "Pick at least one country. Until then nothing is filtered."
                                 else "Only servers in the countries below are allowed."
            CountryMode.BLOCK -> "Servers in the countries below are blocked."
        }
        c1.addView(tv("$blurb Servers with an unknown location are let through.", 12f, GRAY), lp(8))
        if (mode != CountryMode.OFF) {
            val sel = Monitor.countries.sorted()
            val items = sel.map { "${Countries.flag(it)} ${Countries.name(it)}  ✕" to true } + listOf("+ Add" to false)
            c1.addView(chipRow(items) { i ->
                if (i < sel.size) { Monitor.countries = Monitor.countries - sel[i]; changed() } else pickCountries()
            }, lp(10))
            c1.addView(label("Quick add a region"), lp(12))
            val regionNames = Countries.regions.keys.toList()
            c1.addView(chipRow(regionNames.map { n -> n to Countries.regions[n]!!.all { c -> c in Monitor.countries } }) { i ->
                val codes = Countries.regions[regionNames[i]]!!
                Monitor.countries = if (codes.all { it in Monitor.countries }) Monitor.countries - codes.toSet() else Monitor.countries + codes
                changed()
            }, lp(6))
            c1.addView(label("Seen this session (tap to add or remove)"), lp(12))
            val sb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            seenBox = sb; c1.addView(sb, lp(6)); refreshSeen()
        }
        b.addView(c1, lp(10))

        // Auto filter
        val c2 = card()
        c2.addView(sectionTitle(R.drawable.ic_timer, "Auto filter"))
        c2.addView(switchRow("Block slow servers automatically", "Uses the ICMP ping readings", Monitor.autoOn) { Monitor.autoOn = it; changed() }, lp(10))
        val opts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; alpha = if (Monitor.autoOn) 1f else 0.45f }
        val pings = listOf(50, 80, 100, 150, 200, 300)
        opts.addView(label("Presets"), lp(0))
        opts.addView(chipRow(presetNames.mapIndexed { i, n -> n to presetActive(i) }) { i -> applyPreset(i) }, lp(6))
        opts.addView(label("Max ping"), lp(12))
        opts.addView(chipRow(pings.map { "$it ms" to (Monitor.maxPing == it) } +
            listOf((if (Monitor.maxPing in pings) "Custom" else "${Monitor.maxPing} ms ✎") to (Monitor.maxPing !in pings))) { i ->
            if (i < pings.size) { Monitor.maxPing = pings[i]; changed() }
            else askNumber("Max ping (ms)", Monitor.maxPing) { Monitor.maxPing = it; changed() }
        }, lp(6))
        val jit = listOf(0, 15, 30, 50)
        opts.addView(label("Max jitter"), lp(12))
        opts.addView(chipRow(jit.map { (if (it == 0) "Off" else "$it ms") to (Monitor.maxJitter == it) }) { i ->
            Monitor.maxJitter = jit[i]; changed()
        }, lp(6))
        val loss = listOf(0, 5, 10, 20)
        opts.addView(label("Max packet loss"), lp(12))
        opts.addView(chipRow(loss.map { (if (it == 0) "Off" else "$it%") to (Monitor.maxLoss == it) }) { i -> Monitor.maxLoss = loss[i]; changed() }, lp(6))
        val strikes = listOf(2, 3, 5, 8)
        opts.addView(label("Readings in a row before acting"), lp(12))
        opts.addView(chipRow(strikes.map { "$it" to (Monitor.strikes == it) }) { i -> Monitor.strikes = strikes[i]; changed() }, lp(6))
        opts.addView(switchRow("Unblock when ping recovers", "Needs the game to keep retrying that server", Monitor.autoUnblock) {
            Monitor.autoUnblock = it; changed()
        }, lp(14))
        c2.addView(opts, lp(12))
        c2.addView(tv("A server is blocked after ${Monitor.strikes} readings in a row over ${Monitor.maxPing} ms" +
            (if (Monitor.maxJitter > 0) " or ${Monitor.maxJitter} ms jitter" else "") + (if (Monitor.maxLoss > 0) " or ${Monitor.maxLoss}% loss" else "") + ". Servers that never answer ping are never auto-blocked.", 11f, GRAY), lp(10))
        b.addView(c2, lp(10))

        // Alerts
        val c4 = card()
        c4.addView(sectionTitle(R.drawable.ic_signal, "Alerts"))
        c4.addView(switchRow("Haptic alert on a new match server", "Short buzz = ping within your limit, double buzz = over it", Monitor.haptics) {
            Monitor.haptics = it; Monitor.save()
        }, lp(10))
        val idleOpts = listOf(0, 10, 30, 60)
        c4.addView(label("Stop monitoring after no game traffic for"), lp(12))
        c4.addView(chipRow(idleOpts.map { (if (it == 0) "Never" else "$it min") to (Monitor.idleStopMin == it) }) { i ->
            Monitor.idleStopMin = idleOpts[i]; changed()
        }, lp(6))
        c4.addView(tv("Alerts: a heads-up buzz when your match server gets blocked (search again), a lag-spike warning that says whether it's the server or your Wi-Fi, and a summary when a match ends.", 11f, GRAY), lp(10))
        c4.addView(tv("Quick toggles: pull down the notification panel, tap the pencil (edit) icon and drag in the SoundWave tile (monitoring on/off) and the Filters tile (pause/resume all filters). A notification with Stop and Filters buttons also appears while monitoring.", 11f, GRAY), lp(10))
        b.addView(c4, lp(10))

        // Overlay & performance
        val c5 = card()
        c5.addView(sectionTitle(R.drawable.ic_speed, "Overlay & performance"))
        c5.addView(tv("Choose what the floating panel shows over your game.", 12f, GRAY), lp(8))
        c5.addView(switchRow("FPS", "Screen frame rate, measured while the panel is open", Monitor.ovFps) { Monitor.ovFps = it; Monitor.save() }, lp(10))
        c5.addView(switchRow("CPU", "System load (estimated on most phones)", Monitor.ovCpu) { Monitor.ovCpu = it; Monitor.save() }, lp(10))
        c5.addView(switchRow("RAM", "Memory in use", Monitor.ovRam) { Monitor.ovRam = it; Monitor.save() }, lp(10))
        c5.addView(switchRow("Temperature", "Battery temperature", Monitor.ovTemp) { Monitor.ovTemp = it; Monitor.save() }, lp(10))
        c5.addView(switchRow("Block IPv6", "Stops the game skipping your filters over IPv6. Turn off if the game won't connect on an IPv6-only network. Applies next time you press Start.", Monitor.blockV6) {
            Monitor.blockV6 = it; Monitor.save()
        }, lp(14))
        b.addView(c5, lp(10))

        // Lists
        val c3 = card()
        c3.addView(sectionTitle(R.drawable.ic_shield, "Your lists"))
        c3.addView(tv("Blocked by you: ${Monitor.blockSet.size} · Trusted (filters skip these): ${Monitor.trustSet.size}", 12f, GRAY), lp(8))
        c3.addView(chipRow(listOf("Clear blocked" to false, "Clear trusted" to false)) { i ->
            if (i == 0) Monitor.blockSet.clear() else Monitor.trustSet.clear(); changed()
        }, lp(10))
        b.addView(c3, lp(10))
    }

    private fun refreshSeen() {
        val box = seenBox ?: return
        val now = System.currentTimeMillis()
        val groups = Monitor.servers.values.filter { it.geo == 1 && (now - it.lastSeen < 60000 || it.blocked) }.groupBy { it.country }
        val codes = groups.keys.sorted()
        val sig = codes.joinToString(",") { it + groups[it]!!.size + (it in Monitor.countries) }
        if (sig == seenSig) return
        seenSig = sig
        box.removeAllViews()
        if (codes.isEmpty()) { box.addView(tv("Nothing yet. Start monitoring and search for a match.", 12f, GRAY)); return }
        box.addView(chipRow(codes.map { "${Countries.flag(it)} $it · ${groups[it]!!.size}" to (it in Monitor.countries) }) { i ->
            val c = codes[i]
            Monitor.countries = if (c in Monitor.countries) Monitor.countries - c else Monitor.countries + c
            changed()
        })
    }

    private fun pickCountries() {
        val sel = Monitor.countries.toMutableSet()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        val search = EditText(this).apply { hint = "Search countries"; setSingleLine() }
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun render(qs: String) {
            listBox.removeAllViews()
            Countries.all.filter { qs.isBlank() || it.second.contains(qs, true) || it.first.equals(qs, true) }.forEach { (code, name) ->
                val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
                val cb = CheckBox(this).apply { isChecked = code in sel; isClickable = false }
                row.addView(tv(Countries.flag(code), 20f, INK))
                row.addView(tv(name, 15f, INK), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
                row.addView(cb)
                row.setOnClickListener { if (code in sel) sel.remove(code) else sel.add(code); cb.isChecked = code in sel }
                listBox.addView(row)
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) { render(e?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        render("")
        box.addView(search)
        box.addView(ScrollView(this).apply { addView(listBox) }, LinearLayout.LayoutParams(-1, dp(360)))
        AlertDialog.Builder(this).setTitle("Choose countries").setView(box)
            .setPositiveButton("Done") { _, _ -> Monitor.countries = sel; changed() }
            .setNeutralButton("Clear") { _, _ -> Monitor.countries = emptySet(); changed() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun askNumber(title: String, cur: Int, onOk: (Int) -> Unit) {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(cur.toString()); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> et.text.toString().toIntOrNull()?.let { onOk(it.coerceIn(10, 2000)) } }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- network card ----------
    private fun updateNet() {
        val lvl = Monitor.netLevel()
        netDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(when (lvl) { 0 -> GREEN; 1 -> AMBER; 2 -> RED; else -> GRAY })
        }
        val gw = Monitor.gw
        netLine1.text = if (gw.samples() > 0 && Monitor.netType != "Mobile")
            "${Monitor.netType} · router ${Monitor.fmt(gw.cur())} ms · jitter ${Monitor.fmt(gw.jitterD())} · loss ${gw.lossPct()}%"
        else Monitor.netType
        netLine2.text = Monitor.netText() +
            (if (lvl == 2 && Monitor.netType == "Wi-Fi") "\nTry 5 GHz Wi-Fi, move closer to the router, or use a cable." else "")
    }

    // ---------- presets ----------
    private val presetNames = listOf("Strict", "Balanced", "Relaxed")
    private val presetVals = listOf(intArrayOf(60, 20, 2, 5), intArrayOf(100, 30, 3, 10), intArrayOf(150, 0, 5, 0))
    private fun presetActive(i: Int): Boolean {
        val v = presetVals[i]
        return Monitor.autoOn && Monitor.maxPing == v[0] && Monitor.maxJitter == v[1] && Monitor.strikes == v[2] && Monitor.maxLoss == v[3]
    }
    private fun applyPreset(i: Int) {
        val v = presetVals[i]
        Monitor.maxPing = v[0]; Monitor.maxJitter = v[1]; Monitor.strikes = v[2]; Monitor.maxLoss = v[3]; Monitor.autoOn = true
        changed()
    }

    // ---------- history tab ----------
    private val dateFmt = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
    private val isoFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private fun pingColor(p: Double) = when { p < 80 -> GREEN; p < 150 -> AMBER; else -> RED }
    private fun fmtDur(ms: Long) = "${ms / 60000}m ${(ms / 1000) % 60}s"

    private fun refreshHistory() {
        val sig = "${Monitor.history.size}:${Monitor.history.lastOrNull()?.end}"
        if (sig == histSig) return
        histSig = sig; buildHistory()
    }

    private fun buildHistory() {
        val b = historyBox
        b.removeAllViews()
        val all = synchronized(Monitor.history) { Monitor.history.toList() }
        if (all.isEmpty()) {
            val c = card()
            c.addView(sectionTitle(R.drawable.ic_signal, "No sessions yet"))
            c.addView(tv("Play with monitoring on. Every match server you stay on for 20 seconds or more is saved here with its ping, jitter and loss.", 12f, GRAY), lp(8))
            b.addView(c, lp(0)); return
        }
        val rated = all.filter { it.avg >= 0 }
        val regs = rated.groupBy { it.cc }.map { (cc, l) ->
            val dur = l.sumOf { it.end - it.start }.coerceAtLeast(1L)
            Triple(cc, l.sumOf { it.avg * (it.end - it.start) } / dur, l.size)      // time-weighted average ping
        }.sortedBy { it.second }

        val c1 = card()
        c1.addView(sectionTitle(R.drawable.ic_public, "Your regions (best first)"))
        regs.take(6).forEachIndexed { idx, (cc, avg, n) ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            row.addView(tv(Countries.flag(cc), 18f, INK))
            row.addView(tv("${Countries.name(cc)} · $n session${if (n == 1) "" else "s"}", 13f, INK),
                LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
            row.addView(tv("${Monitor.fmt(avg)} ms", 12f, Color.WHITE, true).apply {
                background = rounded(pingColor(avg), 12); setPadding(dp(8), dp(2), dp(8), dp(2))
            })
            c1.addView(row, lp(if (idx == 0) 8 else 0))
        }
        val hour = rated.groupBy { Calendar.getInstance().apply { timeInMillis = it.start }.get(Calendar.HOUR_OF_DAY) }
            .filter { it.value.size >= 2 }.minByOrNull { e -> e.value.map { it.avg }.average() }
        if (hour != null) c1.addView(tv("Best hour so far: ${"%02d".format(hour.key)}:00 (avg ${Monitor.fmt(hour.value.map { it.avg }.average())} ms)", 12f, GRAY), lp(8))
        c1.addView(chipRow(listOf("Allow only my best 3" to false, "Share CSV" to false, "Clear history" to false)) { i ->
            when (i) {
                0 -> {
                    val top = regs.take(3).map { it.first }.filter { it.length == 2 }
                    if (top.isEmpty()) Toast.makeText(this, "No rated regions yet", Toast.LENGTH_SHORT).show()
                    else {
                        Monitor.countryMode = CountryMode.ALLOW; Monitor.countries = top.toSet(); Monitor.save(); buildFilters()
                        Toast.makeText(this, "Allow only: " + top.joinToString(", "), Toast.LENGTH_LONG).show()
                    }
                }
                1 -> shareCsv(all)
                else -> AlertDialog.Builder(this).setTitle("Clear history?").setMessage("This removes every saved session.")
                    .setPositiveButton("Clear") { _, _ -> Monitor.clearHistory(); histSig = ""; refreshHistory() }
                    .setNegativeButton("Cancel", null).show()
            }
        }, lp(12))
        b.addView(c1, lp(0))

        all.asReversed().take(40).forEach { s ->
            val c = card()
            val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            head.addView(tv(Countries.flag(s.cc), 22f, INK))
            val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            mid.addView(tv(s.place.ifEmpty { s.ip }, 14f, INK, true))
            mid.addView(tv("${dateFmt.format(Date(s.start))} · ${fmtDur(s.end - s.start)}", 11f, GRAY))
            head.addView(mid, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
            head.addView(tv(if (s.avg >= 0) "${Monitor.fmt(s.avg)} ms" else "no ping", 12f, Color.WHITE, true).apply {
                background = rounded(if (s.avg >= 0) pingColor(s.avg) else GRAY, 12); setPadding(dp(8), dp(2), dp(8), dp(2))
            })
            c.addView(head)
            if (s.avg >= 0) c.addView(tv("min ${Monitor.fmt(s.min)} · max ${Monitor.fmt(s.max)} · jitter ${Monitor.fmt(s.jitter)} · loss ${s.loss}% · grade ${Monitor.gradeOf(s.avg, s.jitter, s.loss)}", 11f, GRAY), lp(6))
            b.addView(c, lp(10))
        }
    }

    private fun shareCsv(all: List<Session>) {
        val sb = StringBuilder("start,end,duration_s,ip,country,place,avg_ms,min_ms,max_ms,jitter_ms,loss_pct\n")
        for (s in all) {
            sb.append(isoFmt.format(Date(s.start))).append(',').append(isoFmt.format(Date(s.end))).append(',')
                .append((s.end - s.start) / 1000).append(',').append(s.ip).append(',').append(s.cc).append(",\"")
                .append(s.place.replace("\"", "'")).append("\",").append(Monitor.fmt(s.avg)).append(',')
                .append(Monitor.fmt(s.min)).append(',').append(Monitor.fmt(s.max)).append(',')
                .append(Monitor.fmt(s.jitter)).append(',').append(s.loss).append('\n')
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_SUBJECT, "SoundWave sessions").putExtra(Intent.EXTRA_TEXT, sb.toString()), "Share session log"))
    }

    private fun gradeColor(g: Char) = when (g) { 'A', 'B' -> GREEN; 'C' -> AMBER; 'D' -> RED; else -> GRAY }
    private fun gradeBadge(g: Char): View = tv(g.toString(), 12f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(gradeColor(g)) }
    }

    // ---------- server list ----------
    private fun rowFor(s: Server): View {
        val ping = if (s.samples() == 0) -1 else s.recentAvg(3)
        val blocked = s.blocked
        val col = when { blocked || ping < 0 -> GRAY; ping < 80 -> GREEN; ping < 150 -> AMBER; else -> RED }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(tv(Countries.flag(s.country), 24f, INK))
        val ids = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ids.addView(tv(s.ip, 15f, INK, true))
        ids.addView(tv("UDP ports " + s.ports.sorted().joinToString(", "), 11f, GRAY))
        top.addView(ids, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
        if (!blocked && ping >= 0) top.addView(gradeBadge(Monitor.grade(s)), LinearLayout.LayoutParams(dp(26), dp(26)).apply { rightMargin = dp(8) })
        val label = if (blocked) "BLOCKED" else if (ping < 0) "no ping" else "${Monitor.fmt(s.cur())} ms"
        top.addView(tv(label, 13f, Color.WHITE, true).apply {
            background = rounded(if (blocked) RED else col, 20); setPadding(dp(10), dp(4), dp(10), dp(4))
        })
        body.addView(top)
        body.addView(infoRow(R.drawable.ic_pin, s.place + if (s.isp.isNotEmpty()) " · " + s.isp else ""), lp(8))
        val q = when {
            !s.probed() -> "Measuring ping..."
            s.samples() == 0 -> "No reply to ICMP or TCP probes (server blocks probes, so ping can't be measured)"
            else -> "${s.via} ${Monitor.fmt(s.cur())} ms · avg ${s.avg()} · min ${Monitor.fmt(s.minRtt())} · jitter ${Monitor.fmt(s.jitterD())} · loss ${s.lossPct()}%"
        }
        body.addView(infoRow(R.drawable.ic_signal, q), lp(4))
        if (s.samples() >= 3) body.addView(Spark(this).apply { data = s.series(); color = col }, lp(6, dp(28)))
        val reason = Monitor.reason(s)
        if (blocked && reason != null) body.addView(infoRow(R.drawable.ic_block, "$reason · tap to allow anyway", RED), lp(4))
        else if (s.trusted) body.addView(infoRow(R.drawable.ic_shield, "Trusted: filters skip this server · tap to block", GREEN), lp(4))
        body.setPadding(dp(12), dp(12), dp(14), dp(12))

        val card = LinearLayout(this).apply { background = rounded(CARD, 16, if (blocked) RED else null) }
        val stripe = View(this).apply { background = rounded(col, 2) }
        card.addView(stripe, LinearLayout.LayoutParams(dp(5), -1).apply { setMargins(dp(8), dp(10), 0, dp(10)) })
        card.addView(body, LinearLayout.LayoutParams(0, -2, 1f))
        return FrameLayout(this).apply { setPadding(0, 0, 0, dp(10)); addView(card) }
    }

    // ---------- stats tab ----------
    private inner class StatTile(iconRes: Int, name: String) {
        val value = tv("–", 24f, INK, true)
        val sub = tv("", 11f, GRAY)
        val spark = Spark(this@MainActivity)
        val view: View

        init {
            val head = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            head.addView(iconView(iconRes, PURPLE, 16))
            head.addView(tv(name, 12f, GRAY, true), LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(6) })
            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; background = rounded(CARD, 16); setPadding(dp(12), dp(12), dp(12), dp(10))
            }
            box.addView(head)
            box.addView(value, lp(4))
            box.addView(sub, lp(0))
            box.addView(spark, lp(6, dp(34)))
            view = box
        }
    }

    private lateinit var tCpu: StatTile
    private lateinit var tRam: StatTile
    private lateinit var tFps: StatTile
    private lateinit var tTemp: StatTile
    private lateinit var footView: TextView
    private lateinit var noteView: TextView

    private fun buildStats() {
        val b = statsBox
        b.removeAllViews()
        tCpu = StatTile(R.drawable.ic_speed, "CPU"); tRam = StatTile(R.drawable.ic_memory, "RAM")
        tFps = StatTile(R.drawable.ic_signal, "Display FPS"); tTemp = StatTile(R.drawable.ic_thermo, "Temperature")
        fun pair(a: StatTile, c: StatTile) = LinearLayout(this).apply {
            addView(a.view, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(5) })
            addView(c.view, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(5) })
        }
        b.addView(pair(tCpu, tRam), lp(0))
        b.addView(pair(tFps, tTemp), lp(10))
        val c1 = card()
        c1.addView(sectionTitle(R.drawable.ic_wave, "$APP_NAME footprint"))
        footView = tv("", 12f, GRAY); c1.addView(footView, lp(8))
        b.addView(c1, lp(10))
        val c2 = card()
        c2.addView(sectionTitle(R.drawable.ic_shield, "About these numbers"))
        noteView = tv("", 11f, GRAY); c2.addView(noteView, lp(8))
        b.addView(c2, lp(10))
    }

    private fun heatCol(v: Int, warn: Int, bad: Int) = when { v < 0 -> GRAY; v < warn -> GREEN; v < bad -> AMBER; else -> RED }

    private fun updateStats() {
        val s = SysStats

        val cpu = s.cpuPct
        val cc = heatCol(cpu, 60, 85)
        if (cpu >= 0) {
            tCpu.value.text = (if (s.cpuEstimated) "~" else "") + cpu + "%"
            tCpu.sub.text = (if (s.cpuEstimated) "Estimated from clock speeds · " else "") + s.cores + " cores"
        } else {
            tCpu.value.text = "n/a"; tCpu.sub.text = "Hidden by this device"
        }
        tCpu.value.setTextColor(if (cpu >= 0) cc else GRAY)
        tCpu.spark.fixedMax = 100.0; tCpu.spark.color = cc; tCpu.spark.data = s.cpuHist.list(); tCpu.spark.invalidate()

        val rc = if (s.ramLow) RED else heatCol(s.ramPct, 75, 90)
        tRam.value.text = "${s.ramPct}%"; tRam.value.setTextColor(rc)
        tRam.sub.text = "${s.ramUsedMb} of ${s.ramTotalMb} MB" + if (s.ramLow) " · LOW" else ""
        tRam.spark.fixedMax = 100.0; tRam.spark.color = rc; tRam.spark.data = s.ramHist.list(); tRam.spark.invalidate()

        val fps = FpsMeter.fps; val hz = FpsMeter.refreshHz
        val fc = if (fps <= 0) GRAY else if (fps >= hz * 0.9f) GREEN else if (fps >= hz * 0.6f) AMBER else RED
        tFps.value.text = if (fps > 0) "$fps" else "–"; tFps.value.setTextColor(fc)
        tFps.sub.text = "Screen ${Math.round(hz)} Hz · late frames ${FpsMeter.jankPct}%"
        tFps.spark.fixedMax = hz.toDouble(); tFps.spark.color = fc; tFps.spark.data = s.fpsHist.list(); tFps.spark.invalidate()

        val t = s.battTempC
        val tc = when (s.heatLevel()) { 0 -> GREEN; 1 -> AMBER; 2 -> RED; else -> GRAY }
        tTemp.value.text = if (t > 0) String.format(Locale.US, "%.1f°C", t) else "–"; tTemp.value.setTextColor(tc)
        tTemp.sub.text = if (s.thermal >= 0) s.thermalName() else "Battery sensor"
        tTemp.spark.fixedMax = 60.0; tTemp.spark.color = tc; tTemp.spark.data = s.tempHist.list(); tTemp.spark.invalidate()

        footView.text = "CPU: " + String.format(Locale.US, "%.1f", s.appCpuPct) + "% of the phone (includes the packet relay)\n" +
            "Memory: ${s.appRamMb} MB\n" +
            "Battery: " + (if (s.battPct >= 0) "${s.battPct}%" else "unknown") + if (s.charging) " · charging" else ""
        noteView.text = "Display FPS: Android doesn't let apps read another app's frame rate, so this measures the screen itself: " +
            "frames per second it is showing and how many arrive late. The overlay shows the same live over your game. " +
            "A drop below your refresh rate during a match means the phone is struggling or throttling.\n\n" +
            (if (s.cpuEstimated) "CPU is estimated from core clock speeds because Android blocks real CPU stats for apps.\n\n"
             else if (cpu < 0) "This device hides CPU stats from apps, so the overlay shows $APP_NAME's own CPU use instead.\n\n" else "") +
            "Temperature is the battery sensor plus Android's thermal status. Around 40°C and above, phones usually start throttling."
    }

    // ---------- start / stop ----------
    // The refresh loop only runs while the app is on screen, so it costs nothing while you play.
    private var resumed = false
    override fun onPause() { resumed = false; syncFps(); h.removeCallbacksAndMessages(null); super.onPause() }
    override fun onResume() { super.onResume(); resumed = true; syncFps(); h.removeCallbacksAndMessages(null); tick() }
    override fun onDestroy() { resumed = false; FpsMeter.stop("app"); h.removeCallbacksAndMessages(null); super.onDestroy() }

    /** The frame meter runs only while the Stats tab is on screen. */
    private fun syncFps() {
        if (resumed && tab == 1) FpsMeter.start("app", FpsMeter.displayHz(this)) else FpsMeter.stop("app")
    }

    private fun toggle() {
        if (Monitor.running) {
            startService(Intent(this, GameVpnService::class.java).setAction(GameVpnService.ACTION_STOP))
            return
        }
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, 1) else begin()
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r == 1 && c == RESULT_OK) { begin(); if (pendingPlay) launchGame() }
        pendingPlay = false
    }

    /** One tap: VPN permission -> start monitoring -> floating overlay -> open the game. */
    private fun play() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\", then tap Play again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = VpnService.prepare(this)
        if (i != null) { pendingPlay = true; startActivityForResult(i, 1) }
        else { if (!Monitor.running) begin(); launchGame() }
    }

    private fun selectedPkg(): String? = apps.getOrNull(spin.selectedItemPosition)?.second

    private fun launchGame() {
        val pkg = selectedPkg() ?: return
        startService(Intent(this, OverlayService::class.java))
        val li = packageManager.getLaunchIntentForPackage(pkg)
        if (li != null) startActivity(li) else Toast.makeText(this, "Can't open that app", Toast.LENGTH_SHORT).show()
    }

    private fun begin() {
        // Your block/trust lists and filter settings are kept; auto-block state starts fresh.
        val pkg = selectedPkg()
        if (pkg == null) { Toast.makeText(this, "No game selected", Toast.LENGTH_SHORT).show(); return }
        Monitor.servers.values.forEach { it.autoBlocked = false; it.bad = 0; it.good = 0 }
        startService(Intent(this, GameVpnService::class.java).putExtra(GameVpnService.EXTRA_PKG, pkg))
    }

    private fun tick() {
        val on = Monitor.running
        startBtn.text = if (on) "Stop" else "Start"
        startBtn.background = rounded(if (on) RED else PURPLE, 14)
        startBtn.setCompoundDrawablesRelative(ic(if (on) R.drawable.ic_stop else R.drawable.ic_play, Color.WHITE), null, null, null)
        chip.text = if (on) "● Monitoring" else "Idle"
        chip.setTextColor(if (on) GREEN else GRAY)
        chip.background = rounded(if (on) pal("#E3F4E9", "#173526") else pal("#E8E8F0", "#262638"), 20)
        status.text = if (Monitor.lastError.isEmpty()) hintText else "Last issue: ${Monitor.lastError}\n$hintText"
        status.setTextColor(if (Monitor.lastError.isEmpty()) GRAY else RED)

        val now = System.currentTimeMillis()
        shown = Monitor.servers.values.filter { (it.hits >= 5 && now - it.lastSeen < 60000) || it.blocked }.sortedByDescending { it.lastSeen }
        val active = (if (Monitor.countryMode != CountryMode.OFF) 1 else 0) + (if (Monitor.autoOn) 1 else 0)
        tabServers.text = "Servers (${shown.size})"
        tabFilters.text = if (!Monitor.filtersEnabled) "Filters · off" else if (active > 0) "Filters · $active" else "Filters"
        updateNet()
        when (tab) {
            0 -> {
                empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
                // Rebuild the rows only when something visible changed: no flicker, and taps aren't lost to a refresh.
                val sig = shown.joinToString("|") { "${it.ip}:${it.samples()}:${if (it.samples() > 0) it.cur().toInt() else -1}:${it.blocked}:${it.lossPct()}:${it.jitter()}:${it.place}:${it.trusted}:${it.ports.size}" }
                if (sig != listSig) { listSig = sig; adapter.notifyDataSetChanged() }
            }
            1 -> { SysStats.request(applicationContext); updateStats() }
            2 -> refreshHistory()
            else -> refreshSeen()
        }
        h.postDelayed({ tick() }, 1000)
    }
}
