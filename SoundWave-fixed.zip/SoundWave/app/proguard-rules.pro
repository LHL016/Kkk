# SoundWave uses no reflection; services/tiles are kept automatically via the manifest.
