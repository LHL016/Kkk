# SoundWave

Game ping / latency / server monitor for Android. Routes only the chosen game through a local VPN, measures every
server it talks to, and blocks bad or slow ones. Includes a floating overlay with live performance stats.

## Build
Open the `SoundWave` folder in Android Studio (Hedgehog+ / JDK 17) and run. AGP 8.5.2, Gradle 8.7, minSdk 26.
Command-line: `sh gradlew :app:assembleRelease` or `sh build-apk.sh` (wrapper files are now included). APK lands in `app/build/outputs/apk/release/`.

## What changed from GameNet / "Konami Chudi"
Renamed to SoundWave (package `com.soundwave.app`), new launcher/tile/notification icon, light + dark theme.

### Bugs fixed
- Tunnel read loop could spin a CPU core at high priority (non-blocking fd, no sleep) -> blocking tunnel + guard.
- Quick Stop -> Start left duplicate ping/timer threads running -> generation counter.
- `ping` child processes had no timeout/cleanup, so one hung probe froze a server's ping forever -> watchdog + deadline.
- Gateway pings could stack up on a slow router -> single in-flight probe.
- IPv6 traffic bypassed the tunnel (unfiltered, unmonitored) -> IPv6 is routed in and dropped (toggle: Block IPv6).
- DNS was forced to 8.8.8.8 -> uses the network's own DNS (fallback 8.8.8.8).
- Single geo provider: one rate limit left servers "unknown" and un-filterable -> second provider + retries.
- Server map grew forever -> idle servers pruned after 10 min (block/trust lists kept).
- Server list rebuilt every second (flicker, taps lost) -> rebuilt only when something changed.
- Stale "Last issue" text never cleared; notification channels missing on first alert; crash if no launchable apps;
  SoundWave could be picked as the "game".

- Servers that ignored ICMP showed "no ping" and a fake "loss 100%" (and "no ping data" in match summaries) -> TCP probe fallback; loss only reported for servers that answered.
- "Last issue" showed harmless TCP connect timeouts/refusals as red errors -> only real faults are shown.

### New
- Stats tab + overlay chips: CPU, RAM, FPS, temperature, battery, SoundWave's own CPU/RAM cost, live ping graph.
- Overlay toggles for each stat (Filters tab -> Overlay & performance).

## Honest limits (Android, no root/ADB)
- FPS = display frame rate + late frames, NOT the game's internal FPS (apps can't read other apps' frames).
- CPU is estimated from core clock speeds (Android 8+ blocks /proc/stat); marked with "~". If hidden, the app's own CPU is shown.
- Servers that ignore ICMP are measured with a TCP-handshake probe (ports 443/80; a refused connection still counts as a reply). If both are silent they show "no ping"/"no reply" (not "100% loss") and are never auto-blocked.
- Hand-written TCP relay is basic (no SACK/window scaling); fine for game logins, not a general VPN.

## Build on a phone / AIDE
AGP 8.5.2 needs JDK 17. If Gradle prints "compatible with Java 8 ... Java 11", it is running on Java 8.
Fix: install a JDK 17 and add `org.gradle.java.home=/path/to/jdk17` to `gradle.properties`.
Or skip local builds: push this folder to GitHub, open Actions -> "Build APK" -> Run workflow, download the APK artifact.
